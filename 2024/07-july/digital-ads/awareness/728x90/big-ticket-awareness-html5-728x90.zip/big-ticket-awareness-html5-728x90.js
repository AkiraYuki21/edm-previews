(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._18 = function() {
	this.initialize(img._18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,18);


(lib._2ndprize = function() {
	this.initialize(img._2ndprize);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,247);


(lib.consolation = function() {
	this.initialize(img.consolation);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,83);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,47);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,110,63);


(lib.promo = function() {
	this.initialize(img.promo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,287);


(lib.ticket = function() {
	this.initialize(img.ticket);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,208);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._18();
	this.instance.setTransform(313,-16,0.8233,0.8233);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUAyIgGgBIgEgBIgCgWIAKADIAIABIAFgBQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIADgHIgCAAIgDAAQgGAAgFgCQgFgCgCgGQgCgFABgIIAKguIAVAAIgIAtQgBABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIADABIAAAAIABAAIAFgZIAFgYIAWAAIgPBHQgDAPgIAHQgHAGgNAAIgHAAg");
	this.shape.setTransform(306.15,-6.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUAyIAUhjIAVAAIgVBjg");
	this.shape_1.setTransform(301.9,-9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgRAyIgMgCIAUhiIAVAAIgFAZIADAAQANAAAFAHQAEAGgDAOIgFAVQgCAPgIAGQgHAHgNAAIgLgBgAgEAeIACAAIADgBIACgGIAEgVQABgEgBgBQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(297.0266,-8.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTA0IAPhHIAVAAIgPBHgAABggQgBgDAAgFQABgGAEgCQADgDAFgBQAEABADADQABACgBAGQgBAFgDADQgEADgEAAQgFAAgCgDg");
	this.shape_3.setTransform(292.795,-9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgQAmIgMgDIAGgVIAJADIAIABIAFgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAIgCgCIgCgBIgCgBQgHgDgDgGQgDgGACgIQABgGAEgFQADgFAGgDQAFgEAIAAIAHABQAGAAAFADIgGAUIgHgCIgHgBIgEABQgBAAAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAIADACIABABIADACQAEACADACQAEADABAEIAAAKQgCAHgEAFQgEAGgGADQgHADgJABIgHgBg");
	this.shape_4.setTransform(288.275,-7.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgCAmIAKgyIAAgDIgDgBIgBAAIgBAAIgLA2IgWAAIAPhGIAPgEIALgBQAMAAAEAGQAFAFgCAMIgLA0g");
	this.shape_5.setTransform(282.6786,-7.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAgQgFgHADgOIAFgVQADgOAHgHQAIgHALAAQAMAAAFAHQAFAHgDAOIgFAVQgDAOgHAHQgIAHgLAAQgMAAgFgHgAABgPIgBAEIgEAXQAAABgBAAQAAABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAAAABgBIABgEIAEgXQAAAAABgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAQgBAAAAABg");
	this.shape_6.setTransform(277.075,-7.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AggA0IAVhlIAIgBIAJAAIAHgBQANAAAFAHQAEAHgDAOIgFAWQgCANgIAHQgHAHgNAAIgCAAIgFAagAgBAFIABAAIAEgBIACgFIAEgWQABgEgBgBQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_7.setTransform(270.8766,-6.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQAmIgMgDIAGgVIAJADIAIABIAFgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAIgCgCIgCgBIgCgBQgHgDgDgGQgDgGACgIQABgGAEgFQADgFAGgDQAFgEAIAAIAHABQAGAAAFADIgGAUIgHgCIgHgBIgEABQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAIADACIABABIADACQAEACADACQAEADABAEIAAAKQgCAHgEAFQgEAGgGADQgHADgJABIgHgBg");
	this.shape_8.setTransform(265.625,-7.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgXAfQgFgHADgOIAEgUQACgOAJgHQAHgHAMAAQAMAAAEAHQAEAHgDAOIgEARIgZAAIgBADQAAAEACACQACACAEAAIAGgBIAFAAIgDAUIgJABIgGABQgNAAgHgIgAACgRIgBAEIgBAGIAFAAIABgGIABgEQgBgBAAAAQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAABg");
	this.shape_9.setTransform(260.4998,-7.675);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgBAyIAAgmIgCAAIgIAmIgXAAIAVhjIAYAAQALAAAGADQAFADACAHQABAGgCAIIgCAIQgCAHgDAGQgCAEgFADIACAsgAAAgFIABAAQABAAABgBQAAAAABAAQAAAAABAAQAAgBAAAAQACgCABgDIACgKQAAAAAAgBQABgBgBAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgBAAg");
	this.shape_10.setTransform(254.2667,-9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAyIgGgBIgEgBIgCgWIAKADIAIABIAFgBQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIACgHIgBAAIgCAAQgHAAgFgCQgFgCgCgGQgCgFABgIIAKguIAVAAIgIAtQgBABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIACABIABAAIABAAIAFgZIAFgYIAWAAIgPBHQgDAPgIAHQgHAGgNAAIgHAAg");
	this.shape_11.setTransform(246.5,-6.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgZAgQgEgFACgMIAAgBQADgKAGgFQAIgGALAAIABAAIADABIAAgEQABgEgCgBQgBgCgFAAIgHABIgJADIAKgWIAEgBIAFgBIAGgBQAKABAFACQAFADABAFQACAGgCAIIgKAvIgOADIgMACQgMgBgFgGgAgCAIIgDAEIAAACQAAABAAAAQAAABAAABQAAAAAAABQAAAAABABQAAAAAAAAQAAAAABABQAAAAAAAAQABAAAAAAIACAAIACgOIgCAAIgCACg");
	this.shape_12.setTransform(240.5875,-7.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUAyIAUhjIAWAAIgWBjg");
	this.shape_13.setTransform(236.4,-9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiAyIAVhjIAYAAQALAAAGADQAFADACAHQABAGgCAIIgCAJQgCALgFAFQgFAGgHACQgHACgHAAIgBAAIgIAlgAAAgEIABAAIAFgBIACgGIACgLQAAAAAAgBQABgBgBAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQgBgBAAAAIgBAAg");
	this.shape_14.setTransform(231.5417,-9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJAsIAAgZIgRg+IAVAAIAFAdIAGgdIAVAAIgRA+IAAAZg");
	this.shape_15.setTransform(-353.025,-5.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgTAsIAAhXIATAAIAABDIAUAAIAAAUg");
	this.shape_16.setTransform(-358.35,-5.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWAsIAAhXIAVAAQAJAAAFADQAGADACAFQACAGAAAHIAAAIQAAAJgDAEQgDAGgGACQgGACgGAAIgBAAIAAAggAgCgEIABAAIACgBIABgEIAAgKIgBgEQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_17.setTransform(-363.425,-5.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgWAsIAAhXIAVAAQAJAAAFADQAGADACAFQACAGAAAHIAAAIQAAAJgDAEQgDAGgGACQgGACgGAAIgBAAIAAAggAgCgEIABAAIACgBIABgEIAAgKIgBgEQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_18.setTransform(-368.725,-5.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAGAsIgBgRIgJAAIgBARIgUAAIALhXIAdAAIAMBXgAADAIIgCgXIgBgHIAAAHIgCAXIAFAAg");
	this.shape_19.setTransform(-374.3,-5.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAFgSIAHACIAGABQADAAABgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgBgEgBgGQAAgMAHgGQAFgHAJAAIAJABIALAEIgGARIgGgCIgDgBQgEAAgCACQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIAGAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgDAGQgDAFgFADQgFADgGAAIgLgBg");
	this.shape_20.setTransform(-380.9,-5.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgFATIgEglIASAAIgDAlg");
	this.shape_21.setTransform(-384.6,-7.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgPAnQgGgHAAgNIAAglQAAgNAGgHQAGgHAMAAIAKABIAIADIgHARIgEgCIgDAAIgBAAQgEAAgCADQgBACAAAFIAAAhQAAAFACACQACACAEAAIABAAIADAAIAEgBIAHAQIgJADIgKABQgMABgGgHg");
	this.shape_22.setTransform(-388.125,-5.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgXAoQgHgFAAgNIAAgKQAAgHADgDQADgEAFAAIgEgIIAAgGIAAgGQAAgIABgFQACgFAEgCQAFgDAIAAQAFAAAEADQAEACABAEQACAGAAAIIAAAFIgBAGQgBAEgDADQgCADgFABIAIALIgBgGIgBgFIARAAIAAALIgBAJQgBADgCAEIALARIgUAAIgCgDIgGADIgGABQgOABgGgGgAgKAOIAAACIAAAEQAAAEACACQACADAEAAIABAAIABgBIgKgQgAgGgaIAAADIAAAKIAAABIAAACIADgCQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAAAgBIAAgHIgBgDIgCgBIgCABg");
	this.shape_23.setTransform(-394.1517,-5.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgJAsIAAhDIgNAAIAAgUIAtAAIAAAUIgNAAIAABDg");
	this.shape_24.setTransform(-399.925,-5.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgIA4IAAhvIARAAIAABvg");
	this.shape_25.setTransform(-408.15,-3.825);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgLArIgKgDIAHgRIAFACIAGABQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAgBQACgCAAgDIAAgHIgBgFQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQgCgBgEAAIgGABIgEABIAFgwIAhAAIAAATIgNAAIgCALQAIAAAEAHQAEAGAAALIAAAKQAAAMgGAHQgGAFgKABIgLgCgAABgNIgBAAg");
	this.shape_26.setTransform(-416.875,-4.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLArQgGgDgCgFQgDgEAAgIIAAgLIAAgFIABgEIABgEIAIgVIAIgXIATAAIgHAQIgHARIABgBIABAAQALAAAEAGQAFAGAAAKIAAALQAAAHgDAGQgDAGgFADQgFADgHAAQgGAAgFgCgAAAAEIgBABIAAATQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAAAIABAAIABgCIAAgTIgBgBIgBgBIAAABg");
	this.shape_27.setTransform(-422.15,-5.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgVAtIAAgSIAMgPIAJgOQADgHAAgGIAAgBIgBgGQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAIgHABIgEABIgHgQIAJgEQAHgBAGAAQAHAAAFADQAFAFADAFQADAHAAAHIAAABQAAAGgDAGIgFALIgHAKIgHAJIATAAIAAATg");
	this.shape_28.setTransform(-427.3,-5.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAFgSIAHACIAGABQADAAABgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgBgEgBgGQAAgMAHgGQAFgHAJAAIAJABIALAEIgGARIgGgCIgDgBQgEAAgCACQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIAGAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgDAGQgDAFgFADQgFADgGAAIgLgBg");
	this.shape_29.setTransform(-433.55,-5.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgSAsIAAhXIAlAAIAAATIgTAAIAAAPIAQAAIAAASIgQAAIAAAQIATAAIAAATg");
	this.shape_30.setTransform(-437.9,-5.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgJAsIAAhXIATAAIAABXg");
	this.shape_31.setTransform(-441.55,-5.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AADAsIgGgiIgBAAIAAAiIgUAAIAAhXIAVAAQAJAAAGADQAGADACAFQACAGgBAHIAAAHQABAGgCAFQgCAEgDACIAKAngAgEgFIABAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAIABgEIAAgJIgBgEQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_32.setTransform(-445.75,-5.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgTAsIAAhXIAmAAIAAATIgTAAIAAAPIAQAAIAAASIgQAAIAAAQIATAAIAAATg");
	this.shape_33.setTransform(-450.65,-5.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAGgSIAGACIAFABQAEAAABgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgCgEAAgGQABgMAFgGQAGgHAKAAIAJABIAKAEIgGARIgFgCIgFgBQgDAAgBACQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAABABIAFAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgCAGQgDAFgGADQgFADgGAAIgLgBg");
	this.shape_34.setTransform(-455.3,-5.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-457.9,-16.9,786.5999999999999,21.4);


(lib.ticket_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ticket();
	this.instance.setTransform(-3244,-696,6.9347,6.9347);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ticket_mc, new cjs.Rectangle(-3244,-696,2676.8,1442.5), null);


(lib.sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixVlQhRgigyhGQgzhHgBhwQADiTBlhUQBlhUCbgBQCcABBlBUQBlBUADCTQgCBwgyBHQgzBGhQAiQhSAhhgAAQheAAhTghgAk+HfIAA9kIJ/AAIAAdkg");
	this.shape.setTransform(2720.9,-31.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Al5V3QijgjiZg+ICnpBQB1AxBgAeQBgAfBPAAQB0AAA4gsQA3gsAAhaIAAgRQAChNg7hZQg7haiJiEIh3h2Qh0hwhShuQhShvgsiGQgsiHAAi8IAAgHQAEluC3jJQC3jKFLgDQCCAACZAhQCaAiCXA8IikIYQhegchRgRQhRgRgrAAQhtAAg4AtQg4AuAABXIAAAKQACBHA/BKQA/BJBnBqQAhAkAfAeQAeAgAlAjQB0BxBUBsQBVBtAuCLQAvCKAADNIAAADQgCEAhZC1QhbC2ijBfQiiBejbACQi2AAijglg");
	this.shape_1.setTransform(2581.775,-33.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ApoVzMAAAgrlITLAAIAAJTIpMAAIAAHbIHeAAIAAJVIneAAIAAIQIJSAAIAAJSg");
	this.shape_2.setTransform(2443.675,-33);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ArUVzIAAovIMF5dIqsAAIAApZIVRAAIAAIvIsTZcIMQAAIAAJag");
	this.shape_3.setTransform(2292.2,-33);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ak/VzMAAAgrlIJ/AAMAAAArlg");
	this.shape_4.setTransform(2170.45,-33);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AB0VzIjewnIguAAIAAQnIqAAAMAAAgrlIKuAAQE1ABCtBhQCtBfBFCtQBFCtgDDqIAADIQAADYg2CQQg2CQhjBUIE8TMgAiYi3IAeAAQBTACAjgnQAkglgCheIAAkOQAChagigoQgigohWABIgeAAg");
	this.shape_5.setTransform(2038.525,-33);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AreVzMAAAgrlIKmAAQE2ABCtBhQCtBfBFCtQBFCtgDDsIAADpQgCEqhlCkQhlCliyBAQiyBBjngDIgmAAIAAQEgAheiUIAXAAQBSACAjgnQAlgkgChhIAAktQAChcgkgoQghgohVABIgXAAg");
	this.shape_6.setTransform(1865.2063,-33);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABXVzIAAxMIitAAIAARMIqAAAMAAAgrlIKAAAIAAQdICtAAIAAwdIKAAAMAAAArlg");
	this.shape_7.setTransform(1653.625,-33);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Al5V3QijgjiZg+ICnpBQB1AxBgAeQBgAfBPAAQB0AAA4gsQA3gsAAhaIAAgRQAChNg7hZQg7haiJiEIh3h2Qh0hwhShuQhShvgsiGQgsiHAAi8IAAgHQAEluC3jJQC3jKFLgDQCCAACZAhQCaAiCXA8IikIYQhegchRgRQhRgRgrAAQhtAAg4AtQg4AuAABXIAAAKQACBHA/BKQA/BJBnBqQAhAkAfAeQAeAgAlAjQB0BxBUBsQBVBtAuCLQAvCKAADNIAAADQgCEAhZC1QhbC2ijBfQiiBejbACQi2AAijglg");
	this.shape_8.setTransform(1501.275,-33.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ADOVzIgzohIk1AAIgzIhIpyAAMAFvgrlIOgAAMAFwArlgABdEAIhPrsIgOjoIgNDoIhPLsIC5AAg");
	this.shape_9.setTransform(1338.325,-33);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABeWeQmNgCjKjTQjJjWAAmfIAAynQAAmfDJjWQDKjVGNAAIAEAAQCiAACHAdQCIAcB8A5IjmICQg0gPg8gHQg9gIgvAAIgFAAQh+AAhABPQg/BNAACWIAAQrQACCWBOBNQBPBPCBAAIAEAAQA6AAA6gMQA5gMBDgcIDkIAQiNBFiQAjQiSAiiyAAg");
	this.shape_10.setTransform(1181.125,-33.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ArhVzMAAAgrlIKtAAQDiABCyBjQCyBiBmC5QBpC3ABD/IAARqQgBEChnC8QhoC7iwBmQiyBmjhABgAhhMXIAXAAQBiABAdgtQAcgugDhyIAAy1QAAhsglghQglgihOADIgXAAg");
	this.shape_11.setTransform(971.075,-33);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ApoVzMAAAgrlITLAAIAAJTIpMAAIAAHbIHeAAIAAJVIneAAIAAIQIJSAAIAAJSg");
	this.shape_12.setTransform(821.625,-33);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ApoVzMAAAgrlITLAAIAAJTIpMAAIAAHbIHeAAIAAJVIneAAIAAIQIJSAAIAAJSg");
	this.shape_13.setTransform(684.325,-33);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ak/VzMAAAghvImHAAIAAp2IWOAAIAAJ2ImIAAMAAAAhvg");
	this.shape_14.setTransform(539.4,-33);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJVzIix7oIAAboIqAAAMAAAgrlINLAAICqa+IAA6+IKAAAMAAAArlg");
	this.shape_15.setTransform(373.55,-33);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ADOVzIgzohIk1AAIgzIhIpyAAMAFvgrlIOgAAMAFwArlgABdEAIhPrsIgOjoIgNDoIhPLsIC5AAg");
	this.shape_16.setTransform(190.425,-33);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AB0VzIjewnIguAAIAAQnIqAAAMAAAgrlIKuAAQE1ABCtBhQCtBfBFCtQBFCtgDDqIAADIQAADYg2CQQg2CQhjBUIE8TMgAiYi3IAeAAQBTACAjgnQAkglgCheIAAkOQAChagigoQgigohWABIgeAAg");
	this.shape_17.setTransform(10.675,-33);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ADOVzIgzohIk1AAIgzIhIpyAAMAFvgrlIOgAAMAFwArlgABdEAIhPrsIgOjoIgNDoIhPLsIC5AAg");
	this.shape_18.setTransform(-169.075,-33);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Al9U2QiohPhgilQheijgCj6MAAAggpIKOAAMAAAAg6QAAA+AWAcQAWAbAuAAQAtAAAUgcQAUgdAAg8MAAAgg6IKOAAMAAAAgpQAADehTCkQhQClilBcQijBbj1ACQjdAAimhPg");
	this.shape_19.setTransform(-346.975,-31.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AopTbQi8jDABmAIAA0tQACj1BsitQBpivC5hcQC7hbDtgCQCjAACqAvQCrAuCZBSIjmInQhPgqhbgWQhbgWhaAAQiAAAg9BEQg9BDAECQIAATIQAABIAXAeQAaAfAxgCQAeAAATgHQAQgFAHgFIAAvvIJdAAIAAWRQhyBChlAtQhlAuhtAXQhsAYiGAAQmFAAi6jFg");
	this.shape_20.setTransform(-513.1256,-33.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Aq2WLIAAo0QDCjZC1j1QC2j1B2jpQB2jpADi8IAAgXQgBhwgog8Qgrg8g7gXQg9gXg8ACQhqACheAaQheAbhAAUIjGoTQB2g/C2guQC4guDZgCQDwADCjB1QCjB0BUDCQBUDBACDmIAAANQgCDThCC/QhBDAhqCtQhqCth6CZQh5CZhyCDIJ2AAIAAJSg");
	this.shape_21.setTransform(-721.05,-35.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AiwWIMAAAggnIkhBAIAApTIOjjVMAAAAsPg");
	this.shape_22.setTransform(-865.35,-35.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFE400").s().p("Ak/VzIAAsXIoV/OIKVAAIDDOkIC8ukIKVAAIoVfOIAAMXg");
	this.shape_23.setTransform(1440.5,-370.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFE400").s().p("AACWcQlygCi5jGQi7jIAAlxIAA0yQAEmJDBi+QDDi/FcACIAFAAQFuABC5DIQC5DGAAF1IAAUyQgDGFjAC+Qi/C+laAAgAhEslQgSAeAAA+IAAWWQAAA+AUAdQAWAbAsAAIACAAQAtAAAUgdQAVgcAAg9IAA2WQAAhAgWgcQgYgdgqAAIgEAAQgtAAgTAdg");
	this.shape_24.setTransform(1267.325,-371.526);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFE400").s().p("AlXVdQihgtimhXIDoooQBQAsBFAVQBFAWBAAAQBgAAAog7QAng6gCh/IAA+bIKOAAMAAAAgFQgEFyjBDLQjBDKlPADQiBAAiggrg");
	this.shape_25.setTransform(1101.95,-368.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFE400").s().p("Ak/VzIAAsXIoU/OIKUAAIDDOkIC8ukIKUAAIoUfOIAAMXg");
	this.shape_26.setTransform(903.95,-370.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFE400").s().p("AqLVzMAAAgrlIKAAAMAAAAhvIKXAAIAAJ2g");
	this.shape_27.setTransform(736.075,-370.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFE400").s().p("Al9U2QiohPhgilQheijgCj6MAAAggpIKOAAMAAAAg6QAAA+AWAcQAWAbAuAAQAtAAAUgcQAUgdAAg8MAAAgg6IKOAAMAAAAgpQAADehTCkQhQClilBcQijBbj1ACQjdAAimhPg");
	this.shape_28.setTransform(572.825,-369.175);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFE400").s().p("AlXVdQihgtimhXIDoooQBQAsBFAVQBFAWBAAAQBfAAApg7QAng6gCh/IAA+bIKOAAMAAAAgFQgEFyjBDLQjBDKlPADQiBAAiggrg");
	this.shape_29.setTransform(404,-368.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_caption_mc, new cjs.Rectangle(-1175.1,-584.9,4218.799999999999,845.0999999999999), null);


(lib.second_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2ndprize();
	this.instance.setTransform(-139,-123.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.second_prize_mc, new cjs.Rectangle(-139,-123.5,278,247), null);


(lib.promo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.promo();
	this.instance.setTransform(-2765,-536,3.8791,3.8791);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.promo_mc, new cjs.Rectangle(-2765,-536,1078.4,1113.3), null);


(lib.other_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.consolation();
	this.instance.setTransform(-765,-747,12.3287,12.3287);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.other_prize_mc, new cjs.Rectangle(-765,-747,3279.5,1023.3), null);


(lib.cta_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cta();
	this.instance.setTransform(337,-631,17.0176,17.0176);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_mc, new cjs.Rectangle(337,-631,4152.3,799.9), null);


(lib.bt_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-4595,-107,10.7442,10.7442);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bt_logo, new cjs.Rectangle(-4595,-107,1181.9,676.9), null);


// stage content:
(lib.bigticketawarenesshtml5728x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// footer
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(421,84,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(141));

	// logo
	this.instance_1 = new lib.bt_logo();
	this.instance_1.setTransform(363.95,25.9,0.0767,0.0767,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(108).to({alpha:0},16).wait(17));

	// cta
	this.instance_2 = new lib.cta_mc();
	this.instance_2.setTransform(363.95,58.25,0.0538,0.0538,0,0,0,0,1.9);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(124).to({_off:false},0).wait(1).to({regX:2413.1,regY:-231.1,x:493.85,y:45.65,alpha:0.0032},0).wait(1).to({alpha:0.0145},0).wait(1).to({y:45.55,alpha:0.0371},0).wait(1).to({y:45.4,alpha:0.077},0).wait(1).to({y:45.2,alpha:0.1467},0).wait(1).to({y:44.8,alpha:0.2672},0).wait(1).to({y:44.3,alpha:0.4164},0).wait(1).to({y:43.8,alpha:0.5648},0).wait(1).to({y:43.35,alpha:0.6887},0).wait(1).to({y:43.05,alpha:0.7859},0).wait(1).to({y:42.8,alpha:0.8625},0).wait(1).to({y:42.6,alpha:0.9229},0).wait(1).to({y:42.45,alpha:0.9628},0).wait(1).to({y:42.35,alpha:0.9857},0).wait(1).to({alpha:0.9969},0).wait(1).to({regX:0,regY:1,x:363.95,y:54.9,alpha:1},0).wait(1));

	// ticket
	this.instance_3 = new lib.ticket_mc();
	this.instance_3.setTransform(100,42.7,0.0748,0.0748,0,0,0,0,0.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(108).to({_off:false},0).wait(1).to({regX:-1905.6,regY:25.2,x:-41.7,y:44.55},0).wait(1).to({x:-38.7},0).wait(1).to({x:-32.75},0).wait(1).to({x:-22.2},0).wait(1).to({x:-3.8,y:44.6},0).wait(1).to({x:28,y:44.65},0).wait(1).to({x:67.4,y:44.7},0).wait(1).to({x:106.55,y:44.75},0).wait(1).to({x:139.25,y:44.8},0).wait(1).to({x:164.9,y:44.85},0).wait(1).to({x:185.15},0).wait(1).to({x:201.1,y:44.9},0).wait(1).to({x:211.6},0).wait(1).to({x:217.65},0).wait(1).to({x:220.6,y:44.95},0).wait(1).to({regX:0,regY:0,x:363.95,y:43.1},0).wait(17));

	// sub_caption
	this.instance_4 = new lib.sub_caption_mc();
	this.instance_4.setTransform(363.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).wait(1).to({regX:922.5,regY:-202.3,x:450.1,y:43.35,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({y:43.3,alpha:0.0435},0).wait(1).to({y:43.2,alpha:0.0919},0).wait(1).to({y:43.05,alpha:0.1816},0).wait(1).to({y:42.75,alpha:0.3248},0).wait(1).to({y:42.45,alpha:0.4878},0).wait(1).to({y:42.15,alpha:0.6345},0).wait(1).to({y:41.95,alpha:0.7499},0).wait(1).to({y:41.8,alpha:0.8388},0).wait(1).to({y:41.65,alpha:0.9088},0).wait(1).to({y:41.55,alpha:0.9564},0).wait(1).to({y:41.5,alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:1.1,regY:0.6,x:363.75,y:60.5,alpha:1},0).wait(20).to({regX:922.5,regY:-202.3,x:450.1,y:41.5,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({y:41.55,alpha:0.9565},0).wait(1).to({y:41.65,alpha:0.9081},0).wait(1).to({y:41.8,alpha:0.8184},0).wait(1).to({y:42.1,alpha:0.6752},0).wait(1).to({y:42.4,alpha:0.5122},0).wait(1).to({y:42.7,alpha:0.3655},0).wait(1).to({y:42.9,alpha:0.2501},0).wait(1).to({y:43.05,alpha:0.1612},0).wait(1).to({y:43.2,alpha:0.0912},0).wait(1).to({y:43.3,alpha:0.0436},0).wait(1).to({y:43.35,alpha:0.0166},0).wait(1).to({alpha:0.0036},0).wait(1).to({regX:1.1,regY:0.6,x:363.75,y:62.4,alpha:0},0).wait(77));

	// other_prize
	this.instance_5 = new lib.other_prize_mc();
	this.instance_5.setTransform(363.95,70.3,0.0689,0.0689,0,0,0,0,0.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(57).to({_off:false},0).wait(1).to({regX:874.7,regY:-235.4,x:424.2,y:54,alpha:0.0037},0).wait(1).to({y:53.85,alpha:0.0167},0).wait(1).to({y:53.6,alpha:0.0435},0).wait(1).to({y:53.1,alpha:0.0919},0).wait(1).to({y:52.2,alpha:0.1816},0).wait(1).to({y:50.75,alpha:0.3248},0).wait(1).to({y:49.1,alpha:0.4878},0).wait(1).to({y:47.65,alpha:0.6345},0).wait(1).to({y:46.5,alpha:0.7499},0).wait(1).to({y:45.6,alpha:0.8388},0).wait(1).to({y:44.9,alpha:0.9088},0).wait(1).to({y:44.4,alpha:0.9564},0).wait(1).to({y:44.15,alpha:0.9834},0).wait(1).to({y:44,alpha:0.9964},0).wait(1).to({regX:0,regY:0.8,x:363.95,y:60.25,alpha:1},0).wait(37).to({regX:874.7,regY:-235.4,x:424.3,y:43.95,alpha:0.9968},0).wait(1).to({x:424.7,alpha:0.9855},0).wait(1).to({x:425.55,alpha:0.9629},0).wait(1).to({x:427.05,alpha:0.923},0).wait(1).to({x:429.7,y:43.9,alpha:0.8533},0).wait(1).to({x:434.25,y:43.85,alpha:0.7328},0).wait(1).to({x:439.85,y:43.8,alpha:0.5836},0).wait(1).to({x:445.45,y:43.7,alpha:0.4352},0).wait(1).to({x:450.1,y:43.65,alpha:0.3113},0).wait(1).to({x:453.75,y:43.6,alpha:0.2141},0).wait(1).to({x:456.65,alpha:0.1375},0).wait(1).to({x:458.9,y:43.55,alpha:0.0771},0).wait(1).to({x:460.45,alpha:0.0372},0).wait(1).to({x:461.3,alpha:0.0143},0).wait(1).to({x:461.7,alpha:0.0031},0).wait(1).to({regX:0,regY:0.8,x:401.6,y:59.8,alpha:0},0).wait(17));

	// second_prize_mc
	this.instance_6 = new lib.second_prize_mc();
	this.instance_6.setTransform(218.85,54.5,0.3658,0.3658);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(57).to({_off:false},0).wait(1).to({y:54.4677,alpha:0.0037},0).wait(1).to({y:54.3535,alpha:0.0167},0).wait(1).to({y:54.1197,alpha:0.0435},0).wait(1).to({y:53.6962,alpha:0.0919},0).wait(1).to({y:52.9113,alpha:0.1816},0).wait(1).to({y:51.658,alpha:0.3248},0).wait(1).to({y:50.232,alpha:0.4878},0).wait(1).to({y:48.9485,alpha:0.6345},0).wait(1).to({y:47.9383,alpha:0.7499},0).wait(1).to({y:47.1606,alpha:0.8388},0).wait(1).to({y:46.5483,alpha:0.9088},0).wait(1).to({y:46.1315,alpha:0.9564},0).wait(1).to({y:45.8949,alpha:0.9834},0).wait(1).to({y:45.7815,alpha:0.9964},0).wait(1).to({y:45.75,alpha:1},0).wait(69));

	// promo
	this.instance_7 = new lib.promo_mc();
	this.instance_7.setTransform(390.25,43.5,0.078,0.078,0,0,0,1.3,0.7);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regX:-2225.8,regY:20.7,x:216.35,y:45.05,alpha:0.0037},0).wait(1).to({x:216,alpha:0.0167},0).wait(1).to({x:215.3,alpha:0.0435},0).wait(1).to({x:214,alpha:0.0919},0).wait(1).to({x:211.65,alpha:0.1816},0).wait(1).to({x:207.9,alpha:0.3248},0).wait(1).to({x:203.6,alpha:0.4878},0).wait(1).to({x:199.75,alpha:0.6345},0).wait(1).to({x:196.7,alpha:0.7499},0).wait(1).to({x:194.35,alpha:0.8388},0).wait(1).to({x:192.5,alpha:0.9088},0).wait(1).to({x:191.25,alpha:0.9564},0).wait(1).to({x:190.55,alpha:0.9834},0).wait(1).to({x:190.2,alpha:0.9964},0).wait(1).to({regX:0,regY:0.7,x:363.95,y:43.5,alpha:1},0).wait(42).to({alpha:0},15).to({_off:true},1).wait(68));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5050F").s().p("Eg5JAHLIAAuVMByTAAAIAAOVg");
	this.shape.setTransform(364.075,45.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(141));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(221.4,35.6,508.5,64.1);
// library properties:
lib.properties = {
	id: '8F9B67423E0CC34A8BA2D26890153A40',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_18.jpg", id:"_18"},
		{src:"images/_2ndprize.jpg", id:"_2ndprize"},
		{src:"images/consolation.jpg", id:"consolation"},
		{src:"images/cta.jpg", id:"cta"},
		{src:"images/logo.jpg", id:"logo"},
		{src:"images/promo.jpg", id:"promo"},
		{src:"images/ticket.jpg", id:"ticket"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F9B67423E0CC34A8BA2D26890153A40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;