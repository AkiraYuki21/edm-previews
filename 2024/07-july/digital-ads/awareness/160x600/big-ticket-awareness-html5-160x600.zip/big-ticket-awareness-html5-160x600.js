(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._18 = function() {
	this.initialize(img._18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,18);


(lib._2ndprize = function() {
	this.initialize(img._2ndprize);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,247);


(lib.consolation = function() {
	this.initialize(img.consolation);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,83);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,47);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,110,63);


(lib.promo = function() {
	this.initialize(img.promo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,287);


(lib.ticket = function() {
	this.initialize(img.ticket);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,208);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.ticket_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ticket();
	this.instance.setTransform(-288,-870,1.4938,1.4938);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ticket_mc, new cjs.Rectangle(-288,-870,576.6,310.70000000000005), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAeIgDgBIgCgBIgBgMIAFABIAFABIADgBQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAIACgEIgCAAIgBAAIgHgBQgCgCgBgDQgCgDACgEIAFgcIAMAAIgFAbIAAACIACAAIAAAAIABAAIACgOIADgPIAOAAIgJAqQgCAJgFAEQgEAEgHAAIgFAAg");
	this.shape.setTransform(42.5,6.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMAeIAMg7IANAAIgNA7g");
	this.shape_1.setTransform(40.025,4.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKAdIgHgBIAMg5IAMAAIgDAPIACAAQAIAAACADQADAEgCAIIgDANQgBAIgFAEQgEAEgHAAIgHgBgAgCASIABAAIABgBIACgDIACgNIAAgCIgCgBIAAAAg");
	this.shape_2.setTransform(37.1194,4.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLAfIAJgqIAMAAIgJAqgAAAgSQAAgCAAgEIACgEQACgCADAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAABAAAAQgBAEgCACQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_3.setTransform(34.6167,4.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgJAWIgHgBIAEgNIAFACIAEAAIADAAIABgBIAAgCIgBgBIgBgBIgCAAQgEgCgCgDQgBgDABgGIADgGQACgDADgCQADgCAEAAIAFABIAGABIgDAMIgFgBIgDgBIgDABIgBABIAAACIACABIABAAIABABIAFADIACADIAAAGIgDAIQgCADgEACQgEACgEAAIgFgBg");
	this.shape_4.setTransform(31.975,5.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgBAWIAGgdIgBgCIgBAAIgBAAIAAAAIgGAfIgNAAIAJgpIAIgCIAHAAQAGAAADADQADADgBAHIgHAeg");
	this.shape_5.setTransform(28.6625,5.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOATQgCgEABgJIADgMQACgIAEgEQAFgEAGAAQAHAAADAEQADAEgCAIIgCAMQgCAJgFAEQgEAEgGAAQgIAAgDgEgAABgJIgBADIgCANIAAACIABABIABgBIAAgCIADgNIAAgDIAAgBIgCABg");
	this.shape_6.setTransform(25.3469,5.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgTAeIANg7IAFAAIAFAAIAEAAQAIAAACADQADAEgCAJIgDANQgBAHgFAEQgEAEgHAAIgBAAIgEAPgAAAADIAAAAIACgBIACgCIACgNIAAgDIgCgBIAAAAg");
	this.shape_7.setTransform(21.6694,6.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgJAWIgHgBIAEgNIAFACIAEAAIADAAIABgBIAAgCIgBgBIgBgBIgCAAQgEgCgCgDQgBgDABgGIADgGQACgDADgCQADgCAEAAIAFABIAGABIgDAMIgFgBIgDgBIgDABIgBABIAAACIACABIABAAIABABIAFADIACADIAAAGIgDAIQgCADgEACQgEACgEAAIgFgBg");
	this.shape_8.setTransform(18.625,5.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgNASQgDgEABgJIADgLQABgIAFgEQAFgEAGAAQAHAAADAEQACAEgCAIIgCAKIgOAAIgBACQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAIAEABIADAAIADAAIgCALIgFABIgDABQgIAAgEgFgAABgKIgBADIAAADIADAAIABgDIAAgDIgBgBIgCABg");
	this.shape_9.setTransform(15.5571,5.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAAAeIAAgXIgBAAIgFAXIgOAAIANg7IAOAAQAGAAADACQAEACABAEIgBAJIgBAEIgDAIIgEAEIABAagAAAgDIABAAIACgBQABAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAgBIABgFQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIgCgBIgBAAg");
	this.shape_10.setTransform(11.925,4.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLAeIgFgBIgCgBIAAgMIAFABIAEABIAEgBQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAIABgEIgBAAIgBAAIgHgBQgDgCgCgDQgBgDABgEIAGgcIAMAAIgEAbIAAACIABAAIAAAAIAAAAIAEgOIADgPIAMAAIgJAqQgCAJgEAEQgEAEgIAAIgDAAg");
	this.shape_11.setTransform(7.35,6.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOATQgDgDABgHIABAAQABgHAEgCQAEgEAGAAIABAAIACAAIAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIgDgBIgFABIgFABIAGgMIACgBIADgBIADAAQAGAAADACQADABABAEQABADgCAFIgFAbIgJACIgGABQgHgBgDgDgAgBAFIgBACIAAABQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAABABQAAAAAAAAQAAAAABAAIAAAAIABgIIgBAAIgBABg");
	this.shape_12.setTransform(3.8807,5.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMAeIAMg7IANAAIgNA7g");
	this.shape_13.setTransform(1.475,4.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgUAeIANg7IANAAQAHAAADACQADACABAEIAAAJIgBAFQgCAGgCADQgEADgDABQgFACgEAAIAAAAIgFAWgAAAgCIABAAIACgBIABgDIACgGIAAgDIgCgBIgBAAg");
	this.shape_14.setTransform(-1.4417,4.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-4.8,0,50.699999999999996,11.3), null);


(lib.sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaDRQgMgGgIgKQgHgLgBgRQABgWAPgNQAPgMAXgBQAYABAPAMQAPANABAWQgBARgHALQgIAKgMAGQgNAFgOAAQgNAAgNgFgAgvBIIAAkdIBfAAIAAEdg");
	this.shape.setTransform(117.375,-290.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4DTQgZgFgXgJIAZhYQASAIAPAFQAOAEAMAAQASAAAHgHQAJgGAAgOIAAgCQAAgMgJgOQgIgNgVgUIgSgSQgRgRgNgPQgMgSgHgUQgGgUAAgdIAAAAQAAg4AcgeQAbgfAyAAQATAAAXAFQAYAFAXAJIgZBRIgbgHQgMgCgGAAQgRAAgIAHQgIAGAAANIAAACQAAALAJALIAZAbIAKAKIAKAKQARARANAQQANAQAHAWQAHAUAAAfIAAABQAAAmgOAcQgNAbgZAPQgZAOggAAQgbAAgZgGg");
	this.shape_1.setTransform(96.375,-291.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhcDTIAAmlIC4AAIAABaIhZAAIAABIIBJAAIAABZIhJAAIAABQIBaAAIAABag");
	this.shape_2.setTransform(75.525,-291.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhtDTIAAhVIB0j1IhmAAIAAhbIDNAAIAABVIh3D1IB2AAIAABbg");
	this.shape_3.setTransform(52.65,-291.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgvDTIAAmlIBfAAIAAGlg");
	this.shape_4.setTransform(34.225,-291.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AARDTIggihIgHAAIAAChIhhAAIAAmlIBoAAQAuABAaAOQAaAOAKAbQALAagBAjIAAAeQAAAhgIAWQgIAVgPAMIAwC6gAgWgbIAEAAQANAAAFgFQAFgGAAgOIAAgpQAAgNgFgHQgFgGgNABIgEAAg");
	this.shape_5.setTransform(14.325,-291.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhuDTIAAmlIBmAAQAuABAaAOQAaAOALAbQAKAaAAAjIAAAkQgBAtgPAYQgPAYgbAKQgbAKgigBIgGAAIAACcgAgOgVIAEAAQALAAAGgGQAFgGAAgOIAAguQAAgNgFgHQgFgGgMABIgEAAg");
	this.shape_6.setTransform(-11.8989,-291.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AANDTIAAimIgZAAIAACmIhhAAIAAmlIBhAAIAACfIAZAAIAAifIBhAAIAAGlg");
	this.shape_7.setTransform(-43.825,-291.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag4DTQgZgFgXgJIAZhYQASAIAPAFQAOAEAMAAQASAAAHgHQAJgGAAgOIAAgCQAAgMgJgOQgIgNgVgUIgSgSQgRgRgNgPQgMgSgHgUQgGgUAAgdIAAAAQAAg4AcgeQAbgfAyAAQATAAAXAFQAYAFAXAJIgZBRIgbgHQgMgCgGAAQgRAAgIAHQgIAGAAANIAAACQAAALAJALIAZAbIAKAKIAKAKQARARANAQQANAQAHAWQAHAUAAAfIAAABQAAAmgOAcQgNAbgZAPQgZAOggAAQgbAAgZgGg");
	this.shape_8.setTransform(-66.875,-291.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAfDTIgIhSIguAAIgHBSIhfAAIA4mlICLAAIA4GlgAAOAnIgMhwIgCgjIgBAjIgMBwIAbAAg");
	this.shape_9.setTransform(-91.425,-291.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAODZQg7AAgfggQgeggAAg/IAAizQAAg/AeggQAfggA7AAIABAAQAYAAAUAEQAVAEATAJIgjBOQgHgDgKgBIgQgBIgBAAQgTAAgJAMQgJAMAAAWIAAChQAAAWALAMQAMAMATAAIABAAQAJAAAIgCQAJgCALgEIAiBNQgWALgVAFQgWAFgbAAg");
	this.shape_10.setTransform(-115.2,-291.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhvDTIAAmlIBoAAQAiABAaAPQAbAOAPAcQAQAcABAmIAACqQAAAngQAdQgQAcgbAPQgbAPggABgAgOB3IADAAQAPABAEgHQAEgHAAgRIAAi1QAAgRgGgFQgGgFgLABIgDAAg");
	this.shape_11.setTransform(136.35,-367.775);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhcDTIAAmlIC4AAIAABaIhZAAIAABIIBJAAIAABZIhJAAIAABQIBaAAIAABag");
	this.shape_12.setTransform(113.775,-367.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhcDTIAAmlIC4AAIAABaIhZAAIAABIIBJAAIAABZIhJAAIAABQIBaAAIAABag");
	this.shape_13.setTransform(93.075,-367.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgvDTIAAlGIg7AAIAAhfIDVAAIAABfIg7AAIAAFGg");
	this.shape_14.setTransform(71.175,-367.775);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAADTIgbkKIAAEKIhhAAIAAmlIB/AAIAZEEIAAkEIBhAAIAAGlg");
	this.shape_15.setTransform(46.125,-367.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAfDTIgIhSIguAAIgHBSIhfAAIA4mlICLAAIA4GlgAAOAnIgMhwIgCgjIgBAjIgMBwIAbAAg");
	this.shape_16.setTransform(18.525,-367.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AARDTIggihIgHAAIAAChIhhAAIAAmlIBoAAQAuABAaAOQAaAOAKAbQALAagBAjIAAAeQAAAhgIAWQgIAVgPAMIAwC6gAgWgbIAEAAQANAAAFgFQAFgGAAgOIAAgpQAAgNgFgHQgFgGgNABIgEAAg");
	this.shape_17.setTransform(-8.675,-367.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAfDTIgIhSIguAAIgHBSIhfAAIA4mlICLAAIA4GlgAAOAnIgMhwIgCgjIgBAjIgMBwIAbAAg");
	this.shape_18.setTransform(-35.775,-367.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag5DKQgZgNgOgZQgPgYAAgmIAAk7IBjAAIAAE+QAAAJADAEQADAFAGAAQAHgBADgEQADgEAAgJIAAk+IBjAAIAAE7QAAAhgNAZQgMAZgZAOQgYAOgmABQgggBgZgLg");
	this.shape_19.setTransform(-62.65,-367.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhTC8QgcgeAAg6IAAjHQABglAQgaQAQgaAcgOQAcgOAjgBQAYABAaAHQAaAHAXAMIgjBTQgMgGgOgEQgNgCgOAAQgTgBgJAKQgJALABAWIAAC3QAAAMADAEQAFAFAGgBIAIgBIADgCIAAiXIBbAAIAADXQgRAKgQAHQgOAGgRAEQgRADgTAAQg6AAgdgdg");
	this.shape_20.setTransform(-87.75,-367.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhoDXIAAhWQAeghAbgkQAbglASgjQARgjAAgdIAAgDQAAgRgGgJQgGgJgIgDQgJgEgJAAQgQABgPAEIgXAHIgehQQARgKAcgHQAbgHAhgBQAjABAZASQAZARAMAdQAOAeAAAiIAAADQgBAfgJAdQgKAdgQAaQgRAagSAXQgSAXgRAUIBeAAIAABag");
	this.shape_21.setTransform(-119.15,-368.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgaDWIAAk7IgrAKIAAhaICLggIAAGrg");
	this.shape_22.setTransform(-140.975,-368.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFE400").s().p("AgvDTIAAh4IhRktIBkAAIAcCNIAdiNIBkAAIhREtIAAB4g");
	this.shape_23.setTransform(76.475,-444.525);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFE400").s().p("AAADZQg3AAgcgeQgcgeAAg4IAAjIQAAg7AegdQAdgdA0AAIABAAQA3AAAcAfQAcAeAAA4IAADIQgBA7gcAcQgeAdgzAAgAgKh5QgCAFAAAJIAADXQAAAKADAEQADAEAGAAIAAAAQAHAAAEgEQADgEAAgKIAAjXQgBgJgDgFQgEgEgGAAIAAAAQgHAAgDAEg");
	this.shape_24.setTransform(50.3,-444.6004);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFE400").s().p("AgzDPQgYgGgagNIAjhUQANAGALAEQAKADAJAAQAPAAAGgJQAFgJAAgSIAAkmIBjAAIAAE2QgBA3gdAfQgeAegxABQgTAAgZgHg");
	this.shape_25.setTransform(25.3,-444.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFE400").s().p("AgvDTIAAh4IhRktIBkAAIAcCNIAdiNIBkAAIhREtIAAB4g");
	this.shape_26.setTransform(-4.575,-444.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFE400").s().p("AhhDTIAAmlIBgAAIAAFGIBkAAIAABfg");
	this.shape_27.setTransform(-29.95,-444.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFE400").s().p("Ag5DKQgagMgOgZQgOgZAAgmIAAk6IBiAAIAAE8QAAAKAEAFQADADAGAAQAHAAADgEQADgEAAgKIAAk8IBjAAIAAE6QAAAigMAYQgNAagYAOQgZANglAAQghABgZgMg");
	this.shape_28.setTransform(-54.6,-444.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFE400").s().p("AgzDPQgYgGgagNIAjhUQANAGALAEQAJADALAAQAOAAAGgJQAFgJAAgSIAAkmIBjAAIAAE2QgBA3geAfQgcAegyABQgTAAgZgHg");
	this.shape_29.setTransform(-80.1,-444.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_caption_mc, new cjs.Rectangle(-151,-477.9,302.1,232.2), null);


(lib.secondprize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2ndprize();
	this.instance.setTransform(-139,-123.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondprize_mc, new cjs.Rectangle(-139,-123.5,278,247), null);


(lib.promo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.promo();
	this.instance.setTransform(-173,-829,1.2421,1.2421);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.promo_mc, new cjs.Rectangle(-173,-829,345.3,356.5), null);


(lib.other_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.consolation();
	this.instance.setTransform(-187,-670,1.4094,1.4094);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.other_prize_mc, new cjs.Rectangle(-187,-670,374.9,117), null);


(lib.cta_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cta();
	this.instance.setTransform(-269,-769,2.206,2.206);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_mc, new cjs.Rectangle(-269,-769,538.3,103.70000000000005), null);


(lib.bt_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-104,-835,1.89,1.89);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bt_logo, new cjs.Rectangle(-104,-835,207.9,119.10000000000002), null);


// stage content:
(lib.bigticketawarenesshtml5160x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// footer
	this.instance = new lib.Symbol1();
	this.instance.setTransform(76.15,591.85,1.4697,1.4697,0,0,0,23.2,5.9);

	this.instance_1 = new lib._18();
	this.instance_1.setTransform(111.2,584.55,0.7259,0.7259);

	this.text = new cjs.Text("SERIES 265   |   T&C'S APPLY", "bold 13px '29LT Bukra Cd'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 143;
	this.text.parent = this;
	this.text.setTransform(80,570.95,0.7095,0.7095);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.instance_1},{t:this.instance}]}).wait(141));

	// footer_bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5050F").s().p("AsfA/IAAh8IY/AAIAAB8g");
	this.shape.setTransform(80,593.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(141));

	// logo
	this.instance_2 = new lib.bt_logo();
	this.instance_2.setTransform(80,378.25,0.4091,0.4091);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(108).to({alpha:0},16).to({_off:true},1).wait(16));

	// cta
	this.instance_3 = new lib.cta_mc();
	this.instance_3.setTransform(80,550.5,0.2872,0.2872,0,0,0,0,0.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(124).to({_off:false},0).wait(1).to({regX:0.1,regY:-717.2,x:80.05,y:344.35,alpha:0.0032},0).wait(1).to({y:344.15,alpha:0.0145},0).wait(1).to({y:343.75,alpha:0.0371},0).wait(1).to({y:343.05,alpha:0.077},0).wait(1).to({y:341.85,alpha:0.1467},0).wait(1).to({y:339.7,alpha:0.2672},0).wait(1).to({y:337.05,alpha:0.4164},0).wait(1).to({y:334.45,alpha:0.5648},0).wait(1).to({y:332.25,alpha:0.6887},0).wait(1).to({y:330.5,alpha:0.7859},0).wait(1).to({y:329.15,alpha:0.8625},0).wait(1).to({y:328.1,alpha:0.9229},0).wait(1).to({y:327.4,alpha:0.9628},0).wait(1).to({y:327,alpha:0.9857},0).wait(1).to({y:326.8,alpha:0.9969},0).wait(1).to({regX:0,regY:0.1,x:80,y:532.8,alpha:1},0).wait(1));

	// ticket
	this.instance_4 = new lib.ticket_mc();
	this.instance_4.setTransform(-119.45,470,0.399,0.399);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(108).to({_off:false},0).wait(1).to({regX:0.3,regY:-714.6,x:-118.7,y:184.85},0).wait(1).to({x:-116.45},0).wait(1).to({x:-111.9},0).wait(1).to({x:-103.95},0).wait(1).to({x:-90.05},0).wait(1).to({x:-66.05},0).wait(1).to({x:-36.25},0).wait(1).to({x:-6.65},0).wait(1).to({x:18.05},0).wait(1).to({x:37.45},0).wait(1).to({x:52.7},0).wait(1).to({x:64.75},0).wait(1).to({x:72.7},0).wait(1).to({x:77.3},0).wait(1).to({x:79.5},0).wait(1).to({regX:0.1,regY:0,x:80.05,y:470},0).wait(17));

	// sub_caption
	this.instance_5 = new lib.sub_caption_mc();
	this.instance_5.setTransform(78.6,572.85,0.5,0.5,0,0,0,0,0.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(15).to({_off:false},0).wait(1).to({regX:-0.2,regY:-367.8,x:78.5,y:388.85,alpha:0.0037},0).wait(1).to({y:388.7,alpha:0.0167},0).wait(1).to({y:388.45,alpha:0.0435},0).wait(1).to({y:387.95,alpha:0.0919},0).wait(1).to({y:387.05,alpha:0.1816},0).wait(1).to({y:385.65,alpha:0.3248},0).wait(1).to({y:384,alpha:0.4878},0).wait(1).to({y:382.55,alpha:0.6345},0).wait(1).to({y:381.4,alpha:0.7499},0).wait(1).to({y:380.5,alpha:0.8388},0).wait(1).to({y:379.8,alpha:0.9088},0).wait(1).to({y:379.3,alpha:0.9564},0).wait(1).to({y:379.05,alpha:0.9834},0).wait(1).to({y:378.9,alpha:0.9964},0).wait(1).to({regX:0,regY:0.1,x:78.6,y:562.85,alpha:1},0).wait(28).to({regX:-0.2,regY:-367.8,x:78.5,y:378.95},0).wait(1).to({y:379.2},0).wait(1).to({y:379.6},0).wait(1).to({y:380.25},0).wait(1).to({y:381.2},0).wait(1).to({y:382.45},0).wait(1).to({y:384.2},0).wait(1).to({y:386.55},0).wait(1).to({y:389.8},0).wait(1).to({y:394.35},0).wait(1).to({y:399.9},0).wait(1).to({y:406.1},0).wait(1).to({y:412.55},0).wait(1).to({y:418.85},0).wait(1).to({y:424.6},0).wait(1).to({y:429.75},0).wait(1).to({y:434.25},0).wait(1).to({y:438.15},0).wait(1).to({y:441.6},0).wait(1).to({y:444.6},0).wait(1).to({y:447.3},0).wait(1).to({y:449.55},0).wait(1).to({y:451.25},0).wait(1).to({y:452.55},0).wait(1).to({y:453.5},0).wait(1).to({y:454.15},0).wait(1).to({y:454.6},0).wait(1).to({y:454.8},0).wait(1).to({regX:0,regY:0.1,x:78.6,y:638.85},0).wait(23).to({regX:-0.2,regY:-367.8,x:79,y:454.9},0).wait(1).to({x:80.9},0).wait(1).to({x:84.65},0).wait(1).to({x:91.3},0).wait(1).to({x:102.9},0).wait(1).to({x:123},0).wait(1).to({x:147.85},0).wait(1).to({x:172.55},0).wait(1).to({x:193.2},0).wait(1).to({x:209.4},0).wait(1).to({x:222.15},0).wait(1).to({x:232.25},0).wait(1).to({x:238.9},0).wait(1).to({x:242.7},0).wait(1).to({x:244.55},0).wait(1).to({regX:0,regY:0.1,x:245.2,y:638.85},0).wait(17));

	// other_prize
	this.instance_6 = new lib.other_prize_mc();
	this.instance_6.setTransform(80,572.25,0.3675,0.3675);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(57).to({_off:false},0).wait(1).to({regX:0.4,regY:-611.5,x:80.15,y:347.5,alpha:0.0037},0).wait(1).to({y:347.35,alpha:0.0167},0).wait(1).to({y:347.05,alpha:0.0435},0).wait(1).to({y:346.5,alpha:0.0919},0).wait(1).to({y:345.55,alpha:0.1816},0).wait(1).to({y:343.95,alpha:0.3248},0).wait(1).to({y:342.15,alpha:0.4878},0).wait(1).to({y:340.55,alpha:0.6345},0).wait(1).to({y:339.3,alpha:0.7499},0).wait(1).to({y:338.3,alpha:0.8388},0).wait(1).to({y:337.55,alpha:0.9088},0).wait(1).to({y:337,alpha:0.9564},0).wait(1).to({y:336.7,alpha:0.9834},0).wait(1).to({y:336.55,alpha:0.9964},0).wait(1).to({regX:0,regY:0,x:80,y:561.25,alpha:1},0).wait(37).to({regX:0.4,regY:-611.5,x:80.65,y:336.55},0).wait(1).to({x:82.4},0).wait(1).to({x:86},0).wait(1).to({x:92.3},0).wait(1).to({x:103.35},0).wait(1).to({x:122.45},0).wait(1).to({x:146.1},0).wait(1).to({x:169.6},0).wait(1).to({x:189.2},0).wait(1).to({x:204.6},0).wait(1).to({x:216.75},0).wait(1).to({x:226.3},0).wait(1).to({x:232.65},0).wait(1).to({x:236.25},0).wait(1).to({x:238.05},0).wait(1).to({regX:0,regY:0,x:238.4,y:561.25},0).wait(17));

	// second_prize
	this.instance_7 = new lib.secondprize_mc();
	this.instance_7.setTransform(-86.25,208.25,0.5432,0.5432,0,0,0,0.2,0.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(49).to({_off:false},0).wait(1).to({regX:0,regY:0,x:-85.8191,y:208.15},0).wait(1).to({x:-83.9621},0).wait(1).to({x:-80.2251},0).wait(1).to({x:-73.6433},0).wait(1).to({x:-62.1424},0).wait(1).to({x:-42.2697},0).wait(1).to({x:-17.6395},0).wait(1).to({x:6.8461},0).wait(1).to({x:27.2887},0).wait(1).to({x:43.3302},0).wait(1).to({x:55.9604},0).wait(1).to({x:65.9323},0).wait(1).to({x:72.5168},0).wait(1).to({x:76.2917},0).wait(1).to({x:78.1319},0).wait(1).to({regX:0.2,regY:0.2,x:78.75,y:208.25},0).wait(44).to({regX:0,regY:0,x:79.1859,y:208.1569},0).wait(1).to({x:81.0603,y:208.1811},0).wait(1).to({x:84.8325,y:208.2298},0).wait(1).to({x:91.4761,y:208.3156},0).wait(1).to({x:103.0851,y:208.4654},0).wait(1).to({x:123.1444,y:208.7244},0).wait(1).to({x:148.0059,y:209.0453},0).wait(1).to({x:172.7216,y:209.3644},0).wait(1).to({x:193.3562,y:209.6307},0).wait(1).to({x:209.5484,y:209.8398},0).wait(1).to({x:222.2973,y:210.0043},0).wait(1).to({x:232.3628,y:210.1343},0).wait(1).to({x:239.0092,y:210.2201},0).wait(1).to({x:242.8196,y:210.2693},0).wait(1).to({x:244.677,y:210.2932},0).wait(1).to({regX:0.2,regY:0.2,x:245.3,y:210.4},0).wait(17));

	// promo
	this.instance_8 = new lib.promo_mc();
	this.instance_8.setTransform(220,472,0.4164,0.4164,0,0,0,0.1,0);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regX:-0.4,regY:-650.8,x:219.25,y:201.05,alpha:0.0037},0).wait(1).to({x:217.45,alpha:0.0167},0).wait(1).to({x:213.7,alpha:0.0435},0).wait(1).to({x:206.9,alpha:0.0919},0).wait(1).to({x:194.35,alpha:0.1816},0).wait(1).to({x:174.3,alpha:0.3248},0).wait(1).to({x:151.5,alpha:0.4878},0).wait(1).to({x:131,alpha:0.6345},0).wait(1).to({x:114.8,alpha:0.7499},0).wait(1).to({x:102.4,alpha:0.8388},0).wait(1).to({x:92.6,alpha:0.9088},0).wait(1).to({x:85.95,alpha:0.9564},0).wait(1).to({x:82.15,alpha:0.9834},0).wait(1).to({x:80.35,alpha:0.9964},0).wait(1).to({regX:0.1,regY:0,x:80.05,y:472,alpha:1},0).wait(35).to({regX:-0.4,regY:-650.8,x:80.35,y:201.05},0).wait(1).to({x:82.15},0).wait(1).to({x:85.85},0).wait(1).to({x:92.3},0).wait(1).to({x:103.55},0).wait(1).to({x:123.05},0).wait(1).to({x:147.2},0).wait(1).to({x:171.2},0).wait(1).to({x:191.25},0).wait(1).to({x:206.95},0).wait(1).to({x:219.35},0).wait(1).to({x:229.1},0).wait(1).to({x:235.55},0).wait(1).to({x:239.25},0).wait(1).to({x:241.05},0).wait(1).to({regX:0.1,regY:0,x:241.8,y:472},0).to({_off:true},17).wait(59));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A5050F").s().p("EgMfAu9MAAAhd5IY/AAMAAABd5g");
	this.shape_1.setTransform(80,299.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(141));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-154.3,299.1,475.1,301);
// library properties:
lib.properties = {
	id: '8F9B67423E0CC34A8BA2D26890153A40',
	width: 160,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_18.jpg", id:"_18"},
		{src:"images/_2ndprize.jpg", id:"_2ndprize"},
		{src:"images/consolation.jpg", id:"consolation"},
		{src:"images/cta.jpg", id:"cta"},
		{src:"images/logo.jpg", id:"logo"},
		{src:"images/promo.jpg", id:"promo"},
		{src:"images/ticket.jpg", id:"ticket"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F9B67423E0CC34A8BA2D26890153A40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;