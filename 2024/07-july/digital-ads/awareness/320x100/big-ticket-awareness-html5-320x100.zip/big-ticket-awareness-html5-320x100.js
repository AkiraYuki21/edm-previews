(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._18 = function() {
	this.initialize(img._18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,18);


(lib._2ndprize = function() {
	this.initialize(img._2ndprize);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,247);


(lib.consolation = function() {
	this.initialize(img.consolation);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,83);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,47);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,110,63);


(lib.promo = function() {
	this.initialize(img.promo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,287);


(lib.ticket = function() {
	this.initialize(img.ticket);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,208);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._18();
	this.instance.setTransform(176,-10,0.6331,0.6331);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAnIgFgBIgDgBIgBgRIAHACIAGABIAFAAIACgCIACgGIgCAAIgBAAIgJgBQgDgCgCgEQgBgEAAgGIAIgkIAQAAIgGAjIAAADIABAAIABAAIABAAIADgTIAEgTIARAAIgMA3QgBALgHAGQgFAFgKAAIgFAAg");
	this.shape.setTransform(171.9,-1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAnIAPhNIAQAAIgQBNg");
	this.shape_1.setTransform(168.65,-3.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgNAmIgJgBIAPhLIAQAAIgEATIACAAQAKAAAEAFQADAFgCAKIgEARQgCALgFAFQgGAFgJAAIgJgBgAgDAXIABAAIACgBIACgEIADgQIAAgEIgCgBIgBAAg");
	this.shape_2.setTransform(164.8521,-3.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPApIAMg3IAQAAIgMA3gAAAgYQAAgDAAgDQABgEACgDQADgDADABQAEgBACADQABADgBAEQgBADgCADQgDACgEABQgDgBgCgCg");
	this.shape_3.setTransform(161.62,-3.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMAdIgJgBIAFgRIAGACIAGABIAEgBIACgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgCIgCgBIgCgBQgFgDgCgDQgCgEABgIQABgEADgEQACgEAFgCQADgDAGAAIAGABIAIACIgEAPIgGgBIgFgBIgDABIgCABIABADIACABIACABIACAAIAFAEQADACABADIgBAIQgBAFgDAEQgCAEgFADQgFACgHAAIgGAAg");
	this.shape_4.setTransform(158.125,-2.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgCAdIAHgmIAAgCQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBAAAAAAIgBAAIgBAAIgIApIgRAAIAMg1IALgDIAIgBQAJAAAEAEQAEAEgCAJIgJAog");
	this.shape_5.setTransform(153.8614,-2.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSAZQgEgGACgLIAEgPQACgLAGgFQAGgGAIAAQAJAAAEAGQAEAFgCALIgEAPQgCALgGAGQgGAFgIAAQgJAAgEgFgAABgMIgBAEIgDARIAAAEQAAAAAAAAQAAAAAAAAQAAABAAAAQABAAAAAAIACgBIAAgEIAEgRIAAgDQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgCABg");
	this.shape_6.setTransform(149.5397,-2.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZAoIARhNIAGgBIAGAAIAGgBQAKAAADAGQAEAFgDALIgDAQQgCALgGAFQgFAFgJAAIgCAAIgFAUgAAAAEIAAAAIADgBIABgEIADgQIABgFIgDgBIAAAAg");
	this.shape_7.setTransform(144.7521,-1.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAdIgJgBIAFgRIAGACIAGABIAEgBIACgCQAAAAAAAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgBgCIgCgBIgCgBQgFgDgCgDQgCgEABgIQABgEADgEQACgEAFgCQADgDAGAAIAGABIAIACIgEAPIgGgBIgFgBIgDABIgCABIABADIACABIACABIACAAIAFAEQADACABADIgBAIQgBAFgDAEQgCAEgFADQgFACgHAAIgGAAg");
	this.shape_8.setTransform(140.725,-2.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAYQgFgFADgMIADgOQACgLAGgFQAGgGAIAAQAKAAADAGQADAFgCALIgDAMIgTAAIgBADQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQACACADAAIAEAAIAFgBIgCAPIgHABIgFABQgKAAgFgGgAACgNIgCAEIAAAEIADAAIABgEIABgEIgCgBIgBABg");
	this.shape_9.setTransform(136.7667,-2.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgBAnIAAgeIgBAAIgGAeIgSAAIAQhNIASAAQAJAAAEADQAEACABAFQABAFgBAHIgBAFQgBAGgDAEQgCADgEADIACAigAAAgEIABAAIAEgBIABgEIACgHIAAgEQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_10.setTransform(132.02,-3.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPAnIgFgBIgDgBIgBgRIAHACIAHABIAEAAIADgCIABgGIgBAAIgCAAIgJgBQgEgCgBgEQgBgEABgGIAHgkIAQAAIgGAjIAAADIACAAIAAAAIAAAAIAFgTIAEgTIAQAAIgLA3QgDALgFAGQgGAFgKAAIgFAAg");
	this.shape_11.setTransform(126.05,-1.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTAZQgDgFACgIIAAgBQACgIAFgDQAFgFAIAAIACAAIABAAIABgCQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQgBgBgDAAIgGABIgGACIAHgQIADgBIAEgCIAEAAQAIABAEACQAEACABAEQABAFgCAGIgHAkIgLACIgJAAQgJAAgEgEgAgBAGIgCAEIgBABIABADIACABIABAAIABgKIgBAAIgBABg");
	this.shape_12.setTransform(121.4836,-2.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgQAnIAQhNIARAAIgRBNg");
	this.shape_13.setTransform(118.3,-3.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgaAnIAQhNIASAAQAJAAAEADQAEACABAFQABAFgCAHIgBAGQgCAIgDAEQgEAFgFABQgGACgFAAIgBAAIgGAdgAAAgDIABAAIADgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAgBIABgIIAAgEQAAAAAAAAQgBgBAAAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_14.setTransform(114.5667,-3.525);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgIAnIAAgXIgOg2IASAAIAEAaIAFgaIASAAIgOA2IAAAXg");
	this.shape_15.setTransform(-21.15,-3.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgRAnIAAhNIARAAIAAA7IASAAIAAASg");
	this.shape_16.setTransform(-25.75,-3.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgTAnIAAhNIASAAQAIABAFACQAEADACAEQACAGAAAGIAAAGQAAAJgDADQgCAFgFABQgFACgGAAIgBAAIAAAdgAgCgDIABAAIACgBIABgEIAAgIIgBgEQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_17.setTransform(-30.125,-3.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgTAnIAAhNIASAAQAIABAFACQAEADACAEQACAGAAAGIAAAGQAAAJgDADQgCAFgFABQgFACgGAAIgBAAIAAAdgAgCgDIABAAIACgBIABgEIAAgIIgBgEQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_18.setTransform(-34.775,-3.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAGAnIgCgQIgHAAIgCAQIgRAAIAKhNIAYAAIALBNgAACAHIgCgUIAAgGIAAAGIgBAUIADAAg");
	this.shape_19.setTransform(-39.55,-3.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgKAnIgIgDIAFgQIAFACIAFABQADAAABgBQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgBIgBgEIgEgGIgEgDIgFgGQgDgCgBgFQgBgDAAgFIAAgBQAAgJAFgGQAGgFAHgBIAIABIAIADIgEAOIgFgBIgDAAIgFABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIAAAEIAFAFIACACIACACIAGAFIADAGIABAKQAAAHgDAFQgCAFgFADQgEACgFABIgKgBg");
	this.shape_20.setTransform(-45.3,-3.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgEARIgDghIAPAAIgDAhg");
	this.shape_21.setTransform(-48.525,-5.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNAhQgFgFgBgMIAAgfQABgMAFgGQAGgFAJgBIAJABIAHACIgHAOIgDAAIgCAAQgEgBgCADQAAACgBAEIAAAcQAAAFABACQADACAEAAIACgBIAEAAIAGAOIgIADIgJABQgJAAgGgHg");
	this.shape_22.setTransform(-51.6,-3.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgVAjQgFgFAAgLIAAgJQAAgFACgEQADgCAFgBIgDgGIgCgGIAAgFQAAgHACgEQABgFAEgCQAEgCAHAAQAEAAAEACQADACACAEQABAFAAAHIAAAFIgBAFQgBADgCADQgCACgEABIAHAJIgBgEIgBgFIAOAAIAAAKIgBAHQAAAEgCADIAKAPIgSAAIgBgDIgGADIgFABQgMAAgGgFgAgJAMIAAADIAAACQAAAEACACQACACADAAIACAAIAAAAIgJgPgAgFgWIgBACIAAAJIAAABIAAACIADgCIACgDIAAgHIgBgCIgCgBIgBABg");
	this.shape_23.setTransform(-56.85,-3.625);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgIAnIAAg7IgLAAIAAgSIAmAAIAAASIgKAAIAAA7g");
	this.shape_24.setTransform(-61.85,-3.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHAxIAAhhIAPAAIAABhg");
	this.shape_25.setTransform(-68.975,-2.55);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgJAmIgJgDIAGgPIAEADIAGABQAAAAABgBQAAAAABAAQAAAAAAgBQAAAAAAgBIABgEIAAgHIAAgEQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAgBgBAAQgCgBgDgBIgFABIgEACIAFgqIAcAAIAAARIgLAAIgBAKQAGAAAEAFQADAFAAAJIAAAJQAAALgFAGQgFAFgJAAIgJgBgAABgLIgBAAg");
	this.shape_26.setTransform(-76.525,-3.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgJAmQgFgDgCgEQgDgEAAgHIAAgJIAAgEIABgFIABgCIAHgTIAHgUIAQAAIgGAOIgGAOIABAAIABAAQAJAAAEAFQAEAFAAAJIAAAJQAAAHgCAFQgDAFgFADQgEADgGAAQgFAAgEgCgAAAADIgBACIAAAQIABACIAAAAIABAAIABgCIAAgQIgBgCIgBAAIAAAAg");
	this.shape_27.setTransform(-81.15,-3.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgSAnIAAgPIAKgNQAFgHADgFQADgHAAgFIAAgBIgBgEIgCgDIgEAAIgFABIgEABIgGgPIAIgDIALgBQAGAAAFADQAEADACAGQADAFAAAGIAAABQAAAGgCAFQgCAEgDAFIgGAJIgHAIIASAAIAAAQg");
	this.shape_28.setTransform(-85.625,-3.675);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgJAnIgJgDIAEgQIAHACIAEABQADAAABgBQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgBIgBgEIgFgGIgDgDIgFgGQgCgCgCgFQgBgDAAgFIAAgBQAAgJAFgGQAFgFAIgBIAIABIAJADIgFAOIgEgBIgEAAIgEABQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIABAEIAEAFIACACIACACIAFAFIAEAGIABAKQAAAHgCAFQgDAFgEADQgFACgFABIgJgBg");
	this.shape_29.setTransform(-91.05,-3.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgQAnIAAhNIAgAAIAAARIgQAAIAAANIAOAAIAAAPIgOAAIAAAPIARAAIAAARg");
	this.shape_30.setTransform(-94.8,-3.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgIAnIAAhNIARAAIAABNg");
	this.shape_31.setTransform(-97.975,-3.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AADAnIgFgeIgBAAIAAAeIgSAAIAAhNIATAAQAIABAEACQAFADACAEQACAGAAAGIAAAFQAAAHgCADQgBAEgDABIAJAjgAgDgEIABAAIACgBIABgEIAAgHIgBgEQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_32.setTransform(-101.625,-3.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgQAnIAAhNIAhAAIAAARIgQAAIAAANIAMAAIAAAPIgMAAIAAAPIAQAAIAAARg");
	this.shape_33.setTransform(-105.9,-3.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgKAnIgIgDIAFgQIAFACIAFABQADAAABgBQAAgBABAAQAAAAAAgBQAAAAAAgBQABAAAAgBIAAgBIgCgEIgEgGIgEgDIgFgGQgCgCgBgFQgCgDAAgFIAAgBQAAgJAFgGQAGgFAIgBIAHABIAIADIgEAOIgFgBIgDAAIgFABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIAAAEIAFAFIACACIACACIAFAFIAEAGIABAKQAAAHgDAFQgCAFgFADQgEACgFABIgKgBg");
	this.shape_34.setTransform(-109.9,-3.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-10,300.3,14.8);


(lib.ticket_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ticket();
	this.instance.setTransform(-1871,-530,4.7611,4.7611);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ticket_mc, new cjs.Rectangle(-1871,-530,1837.8,990.3), null);


(lib.sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhsNOQgygUgfgrQgegsgBhFQAChZA9g0QA+gzBfgBQBgABA9AzQA+A0ACBZQgBBFgfAsQgfArgxAUQgyAVg7AAQg6AAgygVgAjDEmIAAyIIGHAAIAASIg");
	this.shape.setTransform(1153.025,11.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjnNZQhjgVhegmIBmliQBIAeA6ATQA7ASAxABQBHAAAigbQAigbAAg3IAAgLQABgvgkg3Qglg3hThRIhJhIQhHhEgyhDQgzhEgbhTQgahTAAhzIAAgDQACjhBwh8QBwh7DLgCQBPAABeAUQBfAVBcAlIhlFIQg5gRgygLQgxgKgbAAQhDABgiAbQgiAcAAA1IAAAHQABArAmAtQAnAtA/BCIAnAnQATAUAXAWQBHBEAzBCQA1BEAbBVQAdBUAAB+IAAACQgBCdg2BuQg4BwhkA6QhkA6iGABQhvAAhkgXg");
	this.shape_1.setTransform(1067.725,10.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Al5NXIAA6tILvAAIAAFsIloAAIAAEkIElAAIAAFtIklAAIAAFDIFsAAIAAFtg");
	this.shape_2.setTransform(983.125,10.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Am8NXIAAlXIHavlImjAAIAAlxINCAAIAAFXIniPmIHgAAIAAFwg");
	this.shape_3.setTransform(890.275,10.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjDNXIAA6tIGHAAIAAatg");
	this.shape_4.setTransform(815.65,10.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABHNXIiIqMIgcAAIAAKMImIAAIAA6tIGkAAQC9ABBrA7QBqA6AqBrQAqBqgCCOIAAB7QAACFghBZQghBXg9AzIDCLxgAhdhwIATAAQAyABAWgXQAVgXgBg5IAAinQABg2gUgYQgVgZg0ABIgTAAg");
	this.shape_5.setTransform(734.825,10.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AnBNXIAA6tIGfAAQC+ABBqA7QBqA6AqBrQAqBqgCCPIAACQQgBC3g+BkQg9BlhtAnQhuAoiNgCIgXAAIAAJ2gAg5haIAOAAQAyABAVgYQAXgXgBg6IAAi6QABg3gWgYQgUgZg0ABIgOAAg");
	this.shape_6.setTransform(628.5796,10.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA2NXIAAqiIhqAAIAAKiImJAAIAA6tIGJAAIAAKFIBqAAIAAqFIGIAAIAAatg");
	this.shape_7.setTransform(498.925,10.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjnNZQhjgVhegmIBmliQBIAeA6ATQA7ASAxABQBHAAAigbQAigbAAg3IAAgLQABgvgkg3Qglg3hThRIhJhIQhHhEgyhDQgzhEgbhTQgahTAAhzIAAgDQACjhBwh8QBwh7DLgCQBPAABeAUQBfAVBcAlIhlFIQg5gRgygLQgxgKgbAAQhDABgiAbQgiAcAAA1IAAAHQABArAmAtQAnAtA/BCIAnAnQATAUAXAWQBHBEAzBCQA1BEAbBVQAdBUAAB+IAAACQgBCdg2BuQg4BwhkA6QhkA6iGABQhvAAhkgXg");
	this.shape_8.setTransform(405.575,10.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AB+NXIgflNIi9AAIgfFNImAAAIDh6tII5AAIDhatgAA5CdIgwnKIgJiOIgICOIgwHKIBxAAg");
	this.shape_9.setTransform(305.725,10.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AA6NxQjzgBh8iCQh7iDAAj9IAArbQAAj9B7iDQB8iDDzAAIACAAQBkAABSARQBTASBMAjIiNE7QgggJglgFQglgEgcAAIgEAAQhNAAgnAvQgmAwAABcIAAKNQABBcAvAwQAxAvBPAAIACAAQAkABAjgIQAjgHApgRICME6QhWAqhZAWQhZAUhtAAg");
	this.shape_10.setTransform(209.375,10.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AnDNXIAA6tIGkAAQCKABBtA9QBtA7A/ByQA/BwABCcIAAK0QgBCfg+BzQhAByhsA/QhtA+iJABgAg7HlIAOAAQA8AAARgbQASgcgChGIAAriQAAhCgXgVQgWgVgwACIgOAAg");
	this.shape_11.setTransform(1230.025,-214.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Al5NXIAA6tILvAAIAAFtIloAAIAAEjIElAAIAAFuIklAAIAAFDIFsAAIAAFsg");
	this.shape_12.setTransform(1138.425,-214.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Al5NXIAA6tILvAAIAAFtIloAAIAAEjIElAAIAAFuIklAAIAAFDIFsAAIAAFsg");
	this.shape_13.setTransform(1054.275,-214.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AjDNXIAA0rIjwAAIAAmCINnAAIAAGCIjwAAIAAUrg");
	this.shape_14.setTransform(965.475,-214.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgGNXIhsw7IAAQ7ImHAAIAA6tIIDAAIBoQiIAAwiIGIAAIAAatg");
	this.shape_15.setTransform(863.85,-214.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AB+NXIgflOIi9AAIgfFOImAAAIDh6tII5AAIDhatgAA5CdIgwnKIgJiOIgICOIgwHKIBxAAg");
	this.shape_16.setTransform(751.625,-214.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABHNXIiIqLIgcAAIAAKLImIAAIAA6tIGkAAQC9ABBrA7QBqA7AqBpQAqBqgCCQIAAB6QAACFghBZQghBXg9AzIDCLxgAhdhvIATAAQAyABAWgZQAVgWgBg6IAAilQABg3gUgYQgVgag0ABIgTAAg");
	this.shape_17.setTransform(641.475,-214.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AB+NXIgflOIi9AAIgfFOImAAAIDh6tII5AAIDhatgAA5CdIgwnKIgJiOIgICOIgwHKIBxAAg");
	this.shape_18.setTransform(531.275,-214.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AjqMxQhmgwg7hlQg6hkAAiZIAA0AIGQAAIAAUKQAAAmANASQANAQAcAAQAcAAANgRQAMgSAAglIAA0KIGRAAIAAUAQgBCIgyBlQgxBlhmA4QhjA4iWABQiIAAhmgxg");
	this.shape_19.setTransform(422.25,-213.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AlTL6Qhzh3ABjtIAAsrQABiWBChqQBBhrBxg4QByg4CSgBQBjAABoAcQBpAdBeAyIiNFSQgwgbg4gNQg4gNg3AAQhOAAglApQgmAqADBYIAALtQAAAsAOATQAPASAegBQATAAALgDQAKgEAFgDIAAppIFyAAIAANpQhGApg+AbQg9AchDAPQhCAOhTAAQjuAAhyh4g");
	this.shape_20.setTransform(320.4496,-214.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AmpNmIAAlaQB3iFBviWQBwiXBIiOQBIiPAChzIAAgOQgBhEgZglQgaglgkgOQglgOglABQhBABg5AQIhhAdIh6lFQBJgnBwgcQBwgdCFgBQCTACBkBIQBkBHAzB3QA0B2ABCNIAAAIQgBCBgpB1QgoB2hBBqQhABqhMBdQhKBehGBQIGCAAIAAFtg");
	this.shape_21.setTransform(192.975,-215.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhrNkIAAz/IiyAnIAAlsII7iDIAAbHg");
	this.shape_22.setTransform(104.575,-215.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFE400").s().p("AjDNXIAAnlIlHzIIGVAAIB3I8IB0o8IGUAAIlGTIIAAHlg");
	this.shape_23.setTransform(986.9,-438.85);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFE400").s().p("AABNwQjjgBhxh5Qhyh7AAjiIAAsuQACjxB3h1QB2h1DWABIADAAQDgABByB6QBxB6AADlIAAMuQgDDvh0B0Qh2B0jUAAgAgqntQgLATABAmIAANsQgBAmAMARQAOARAbAAIABAAQAbAAANgSQANgRAAglIAAtsQAAgngOgSQgOgRgaAAIgDAAQgbAAgMARg");
	this.shape_24.setTransform(880.85,-439.2004);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFE400").s().p("AjRNJQhjgbhmg1ICOlTQAxAbAqANQArAOAnAAQA6AAAZgkQAYgkgBhNIAAyqIGQAAIAATqQgCDjh2B8Qh3B8jMACQhQAAhhgbg");
	this.shape_25.setTransform(779.425,-437.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFE400").s().p("AjDNXIAAnlIlGzIIGUAAIB3I8IB0o8IGVAAIlHTIIAAHlg");
	this.shape_26.setTransform(658.1,-438.85);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFE400").s().p("AmONXIAA6tIGIAAIAAUrIGVAAIAAGCg");
	this.shape_27.setTransform(555.225,-438.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFE400").s().p("AjqMxQhmgwg7hlQg5hkgBiZIAA0AIGQAAIAAUKQAAAmANASQANAQAcAAQAcAAANgRQAMgSAAglIAA0KIGRAAIAAUAQgBCIgyBlQgxBlhmA4QhjA4iWABQiHAAhngxg");
	this.shape_28.setTransform(455.2,-437.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFE400").s().p("AjRNJQhjgbhmg1ICOlTQAxAbAqANQArAOAnAAQA6AAAZgkQAYgkgBhNIAAyqIGQAAIAATqQgCDjh2B8Qh3B8jMACQhQAAhhgbg");
	this.shape_29.setTransform(351.725,-437.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_caption_mc, new cjs.Rectangle(-275,-570,1903.4,760.2), null);


(lib.second_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2ndprize();
	this.instance.setTransform(-139,-123.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.second_prize_mc, new cjs.Rectangle(-139,-123.5,278,247), null);


(lib.promo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.promo();
	this.instance.setTransform(-1017,-496,3.1301,3.1301);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.promo_mc, new cjs.Rectangle(-1017,-496,870.2,898.4), null);


(lib.other_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.consolation();
	this.instance.setTransform(59,-501,6.2833,6.2833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.other_prize_mc, new cjs.Rectangle(59,-501,1671.4,521.5), null);


(lib.cta_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cta();
	this.instance.setTransform(212,-466,8.858,8.858);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_mc, new cjs.Rectangle(212,-466,2161.4,416.3), null);


(lib.bt_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-1787,50,5.3551,5.3551);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bt_logo, new cjs.Rectangle(-1787,50,589.0999999999999,337.4), null);


// stage content:
(lib.bigticketawarenesshtml5320x100 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// footer
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(123.8,95.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(141));

	// ticket
	this.instance_1 = new lib.ticket_mc();
	this.instance_1.setTransform(83.35,47.5,0.0831,0.0831);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(108).to({_off:false},0).wait(1).to({regX:-952.1,regY:-34.8,x:4.45,y:44.6,alpha:0.0032},0).wait(1).to({x:5.35,alpha:0.0145},0).wait(1).to({x:7.05,alpha:0.0371},0).wait(1).to({x:10.1,alpha:0.077},0).wait(1).to({x:15.45,y:44.65,alpha:0.1467},0).wait(1).to({x:24.7,y:44.7,alpha:0.2672},0).wait(1).to({x:36.1,y:44.75,alpha:0.4164},0).wait(1).to({x:47.5,y:44.8,alpha:0.5648},0).wait(1).to({x:57,y:44.85,alpha:0.6887},0).wait(1).to({x:64.45,y:44.9,alpha:0.7859},0).wait(1).to({x:70.3,alpha:0.8625},0).wait(1).to({x:74.9,y:44.95,alpha:0.9229},0).wait(1).to({x:78,alpha:0.9628},0).wait(1).to({x:79.75,alpha:0.9857},0).wait(1).to({x:80.6,alpha:0.9969},0).wait(1).to({regX:0,regY:0,x:159.95,y:47.9,alpha:1},0).wait(17));

	// logo
	this.instance_2 = new lib.bt_logo();
	this.instance_2.setTransform(159.95,28.8,0.0852,0.0852,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(108).to({alpha:0},16).wait(17));

	// cta
	this.instance_3 = new lib.cta_mc();
	this.instance_3.setTransform(159.95,64.7,0.0598,0.0598,0,0,0,0,0.8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(124).to({_off:false},0).wait(1).to({regX:1292.7,regY:-257.8,x:237.25,y:49.2,alpha:0.0032},0).wait(1).to({y:49.15,alpha:0.0145},0).wait(1).to({y:49.1,alpha:0.0371},0).wait(1).to({y:48.95,alpha:0.077},0).wait(1).to({y:48.7,alpha:0.1467},0).wait(1).to({y:48.25,alpha:0.2672},0).wait(1).to({y:47.7,alpha:0.4164},0).wait(1).to({y:47.15,alpha:0.5648},0).wait(1).to({y:46.7,alpha:0.6887},0).wait(1).to({y:46.3,alpha:0.7859},0).wait(1).to({y:46.05,alpha:0.8625},0).wait(1).to({y:45.8,alpha:0.9229},0).wait(1).to({y:45.65,alpha:0.9628},0).wait(1).to({y:45.6,alpha:0.9857},0).wait(1).to({y:45.55,alpha:0.9969},0).wait(1).to({regX:0,regY:0.8,x:159.95,y:61,alpha:1},0).wait(1));

	// sub_caption
	this.instance_4 = new lib.sub_caption_mc();
	this.instance_4.setTransform(159.7,69.35,0.1042,0.1042,0,0,0,0.5,0.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).wait(1).to({regX:675.6,regY:-214.4,x:230,y:46.9,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({y:46.85,alpha:0.0435},0).wait(1).to({y:46.75,alpha:0.0919},0).wait(1).to({y:46.55,alpha:0.1816},0).wait(1).to({y:46.25,alpha:0.3248},0).wait(1).to({y:45.9,alpha:0.4878},0).wait(1).to({y:45.6,alpha:0.6345},0).wait(1).to({y:45.35,alpha:0.7499},0).wait(1).to({y:45.15,alpha:0.8388},0).wait(1).to({y:45,alpha:0.9088},0).wait(1).to({y:44.9,alpha:0.9564},0).wait(1).to({y:44.85,alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:0.5,regY:0.5,x:159.7,y:67.25,alpha:1},0).wait(20).to({regX:675.6,regY:-214.4,x:230,y:44.85,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({y:44.9,alpha:0.9565},0).wait(1).to({y:45,alpha:0.9081},0).wait(1).to({y:45.2,alpha:0.8184},0).wait(1).to({y:45.5,alpha:0.6752},0).wait(1).to({y:45.85,alpha:0.5122},0).wait(1).to({y:46.15,alpha:0.3655},0).wait(1).to({y:46.4,alpha:0.2501},0).wait(1).to({y:46.6,alpha:0.1612},0).wait(1).to({y:46.75,alpha:0.0912},0).wait(1).to({y:46.85,alpha:0.0436},0).wait(1).to({y:46.9,alpha:0.0166},0).wait(1).to({alpha:0.0036},0).wait(1).to({regX:0.5,regY:0.5,x:159.7,y:69.35,alpha:0},0).wait(77));

	// other_prize
	this.instance_5 = new lib.other_prize_mc();
	this.instance_5.setTransform(159.95,69.2,0.0765,0.0765);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(57).to({_off:false},0).wait(1).to({regX:894.7,regY:-240.2,x:228.45,y:50.75,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({y:50.7,alpha:0.0435},0).wait(1).to({y:50.55,alpha:0.0919},0).wait(1).to({y:50.35,alpha:0.1816},0).wait(1).to({y:50.05,alpha:0.3248},0).wait(1).to({y:49.7,alpha:0.4878},0).wait(1).to({y:49.35,alpha:0.6345},0).wait(1).to({y:49.1,alpha:0.7499},0).wait(1).to({y:48.9,alpha:0.8388},0).wait(1).to({y:48.75,alpha:0.9088},0).wait(1).to({y:48.6,alpha:0.9564},0).wait(1).to({y:48.55,alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:0,regY:0.7,x:159.95,y:66.95,alpha:1},0).wait(37).to({regX:894.7,regY:-240.2,x:228.55,y:48.45,alpha:0.9968},0).wait(1).to({x:229.05,alpha:0.9855},0).wait(1).to({x:230,alpha:0.9629},0).wait(1).to({x:231.65,alpha:0.923},0).wait(1).to({x:234.55,y:48.4,alpha:0.8533},0).wait(1).to({x:239.6,y:48.35,alpha:0.7328},0).wait(1).to({x:245.85,y:48.25,alpha:0.5836},0).wait(1).to({x:252.05,y:48.2,alpha:0.4352},0).wait(1).to({x:257.25,y:48.15,alpha:0.3113},0).wait(1).to({x:261.3,y:48.1,alpha:0.2141},0).wait(1).to({x:264.5,y:48.05,alpha:0.1375},0).wait(1).to({x:267.05,y:48,alpha:0.0771},0).wait(1).to({x:268.7,alpha:0.0372},0).wait(1).to({x:269.7,alpha:0.0143},0).wait(1).to({x:270.15,alpha:0.0031},0).wait(1).to({regX:0,regY:0.7,x:201.8,y:66.45,alpha:0},0).wait(17));

	// second_prize_mc
	this.instance_6 = new lib.second_prize_mc();
	this.instance_6.setTransform(113.05,50.85,0.3125,0.3125,0,0,0,0.1,0);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(57).to({_off:false},0).wait(1).to({regX:0,x:113,y:50.8242,alpha:0.0037},0).wait(1).to({y:50.7328,alpha:0.0167},0).wait(1).to({y:50.5458,alpha:0.0435},0).wait(1).to({y:50.207,alpha:0.0919},0).wait(1).to({y:49.5791,alpha:0.1816},0).wait(1).to({y:48.5764,alpha:0.3248},0).wait(1).to({y:47.4356,alpha:0.4878},0).wait(1).to({y:46.4088,alpha:0.6345},0).wait(1).to({y:45.6006,alpha:0.7499},0).wait(1).to({y:44.9784,alpha:0.8388},0).wait(1).to({y:44.4886,alpha:0.9088},0).wait(1).to({y:44.1552,alpha:0.9564},0).wait(1).to({y:43.966,alpha:0.9834},0).wait(1).to({y:43.8752,alpha:0.9964},0).wait(1).to({regX:0.1,x:113.05,y:43.85,alpha:1},0).wait(69));

	// promo
	this.instance_7 = new lib.promo_mc();
	this.instance_7.setTransform(238.6,48.35,0.0867,0.0867,0,0,0,0.6,0.6);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regX:-581.9,regY:-46.8,x:187.8,y:44.25,alpha:0.0037},0).wait(1).to({x:186.75,alpha:0.0167},0).wait(1).to({x:184.65,alpha:0.0435},0).wait(1).to({x:180.85,alpha:0.0919},0).wait(1).to({x:173.8,alpha:0.1816},0).wait(1).to({x:162.55,alpha:0.3248},0).wait(1).to({x:149.7,alpha:0.4878},0).wait(1).to({x:138.15,alpha:0.6345},0).wait(1).to({x:129.1,alpha:0.7499},0).wait(1).to({x:122.1,alpha:0.8388},0).wait(1).to({x:116.6,alpha:0.9088},0).wait(1).to({x:112.85,alpha:0.9564},0).wait(1).to({x:110.75,alpha:0.9834},0).wait(1).to({x:109.7,alpha:0.9964},0).wait(1).to({regX:0,regY:0.6,x:159.95,y:48.35,alpha:1},0).wait(42).to({alpha:0},15).to({_off:true},1).wait(68));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5050F").s().p("A5JH+IAAv7MAyTAAAIAAP7g");
	this.shape.setTransform(160.025,50.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(141));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(87.9,49.1,246.4,51.99999999999999);
// library properties:
lib.properties = {
	id: '8F9B67423E0CC34A8BA2D26890153A40',
	width: 320,
	height: 100,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_18.jpg", id:"_18"},
		{src:"images/_2ndprize.jpg", id:"_2ndprize"},
		{src:"images/consolation.jpg", id:"consolation"},
		{src:"images/cta.jpg", id:"cta"},
		{src:"images/logo.jpg", id:"logo"},
		{src:"images/promo.jpg", id:"promo"},
		{src:"images/ticket.jpg", id:"ticket"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F9B67423E0CC34A8BA2D26890153A40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;