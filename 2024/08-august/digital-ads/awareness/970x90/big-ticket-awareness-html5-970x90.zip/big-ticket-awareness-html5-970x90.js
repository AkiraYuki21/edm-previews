(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._18 = function() {
	this.initialize(img._18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,18);


(lib._2ndprize = function() {
	this.initialize(img._2ndprize);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,247);


(lib.consolation = function() {
	this.initialize(img.consolation);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,83);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,47);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,110,63);


(lib.promo = function() {
	this.initialize(img.promo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,278,287);


(lib.ticket = function() {
	this.initialize(img.ticket);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,208);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._18();
	this.instance.setTransform(554,-14,0.8233,0.8233);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUAyIgGgBIgEgBIgCgWIAJADIAJABIAFgBQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIADgHIgDAAIgCAAQgGAAgFgCQgFgCgCgGQgDgFACgIIAKguIAVAAIgIAtQgBABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIADABIAAAAIABAAIAFgZIAFgYIAWAAIgPBHQgDAPgIAHQgHAGgOAAIgGAAg");
	this.shape.setTransform(544.55,-3.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVAyIAVhjIAVAAIgUBjg");
	this.shape_1.setTransform(540.3,-6.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgRAyIgMgCIAUhiIAVAAIgFAZIADAAQANAAAFAHQAEAGgDAOIgFAVQgCAPgIAGQgHAHgNAAIgLgBgAgEAeIACAAIADgBIACgGIAEgVQABgEgBgBQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(535.3766,-6.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTA0IAPhHIAVAAIgPBHgAABggQgBgDAAgFQABgGAEgCQADgDAFgBQAEABADADQABACgBAGQgBAFgDADQgEADgEAAQgFAAgCgDg");
	this.shape_3.setTransform(531.145,-6.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgQAmIgMgDIAGgVIAJADIAIABIAFgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAIgCgCIgCgBIgCgBQgHgDgDgGQgDgGACgIQABgGAEgFQADgFAGgDQAFgEAIAAIAHABQAGAAAFADIgGAUIgHgCIgHgBIgEABQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAIADACIABABIADACQAEACADACQAEADABAEIAAAKQgCAHgEAFQgEAGgGADQgHADgJABIgHgBg");
	this.shape_4.setTransform(526.625,-4.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgCAmIAKgyIAAgDIgDgBIgBAAIgBAAIgLA2IgWAAIAPhGIAPgEIALgBQAMAAAEAGQAFAFgCAMIgLA0g");
	this.shape_5.setTransform(521.0286,-5.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAgQgFgHADgOIAFgVQADgOAHgHQAIgHALAAQAMAAAFAHQAFAHgDAOIgFAVQgDAOgHAHQgIAHgLAAQgMAAgFgHgAABgPIgBAEIgEAXQgBABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAQABAAAAgBIABgEIAEgXQABAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAQgBAAAAABg");
	this.shape_6.setTransform(515.425,-4.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AggA0IAVhlIAIgBIAJAAIAHgBQANAAAFAHQAEAHgDAOIgFAWQgCANgIAHQgHAHgNAAIgCAAIgFAagAgBAFIABAAIAEgBIACgFIAEgWQABgEgBgBQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_7.setTransform(509.2266,-3.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQAmIgMgDIAGgVIAJADIAIABIAFgBQAAAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAIgCgCIgCgBIgCgBQgHgDgDgGQgDgGACgIQABgGAEgFQADgFAGgDQAFgEAIAAIAHABQAGAAAFADIgGAUIgHgCIgHgBIgEABQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAIADACIABABIADACQAEACADACQAEADABAEIAAAKQgCAHgEAFQgEAGgGADQgHADgJABIgHgBg");
	this.shape_8.setTransform(503.975,-4.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWAfQgGgHADgOIAEgUQADgOAIgHQAHgHAMAAQAMAAAEAHQAEAHgDAOIgDARIgaAAIgBADQAAAEACACQACACAEAAIAFgBIAGAAIgCAUIgJABIgHABQgOAAgFgIgAACgRIgCAEIAAAGIAFAAIABgGIABgEQgBgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAABg");
	this.shape_9.setTransform(498.8498,-4.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgBAyIAAgmIgCAAIgIAmIgXAAIAVhjIAYAAQALAAAGADQAFADACAHQABAGgCAIIgCAIQgCAHgDAGQgCAEgFADIACAsgAAAgFIABAAQABAAABgBQAAAAABAAQAAAAABAAQAAgBAAAAQACgCABgDIACgKQAAAAAAgBQABgBgBAAQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgBAAg");
	this.shape_10.setTransform(492.6167,-6.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUAyIgGgBIgFgBIgBgWIAJADIAJABIAGgBQAAAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIACgHIgCAAIgBAAQgHAAgFgCQgFgCgCgGQgCgFACgIIAJguIAVAAIgJAtQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAIADABIAAAAIABAAIAFgZIAFgYIAWAAIgPBHQgDAPgIAHQgHAGgOAAIgGAAg");
	this.shape_11.setTransform(484.85,-3.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgZAgQgEgFACgMIAAgBQADgKAGgFQAIgGALAAIABAAIADABIAAgEQABgEgCgBQgBgCgFAAIgHABIgJADIAKgWIAEgBIAFgBIAGgBQAKABAFACQAFADABAFQACAGgCAIIgKAvIgOADIgMACQgMgBgFgGgAgCAIIgDAEIAAACQAAABAAAAQAAABAAABQAAAAAAABQAAAAABABQAAAAAAAAQAAAAABABQAAAAAAAAQABAAAAAAIACAAIACgOIgCAAIgCACg");
	this.shape_12.setTransform(478.9375,-4.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgVAyIAVhjIAWAAIgVBjg");
	this.shape_13.setTransform(474.75,-6.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgiAyIAVhjIAYAAQALAAAGADQAFADACAHQABAGgCAIIgCAJQgCALgFAFQgFAGgHACQgHACgHAAIgBAAIgIAlgAAAgEIABAAIAFgBIACgGIACgLQAAAAAAgBQABgBgBAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAAAgBAAQgBgBAAAAIgBAAg");
	this.shape_14.setTransform(469.8917,-6.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJAsIAAgZIgRg+IAVAAIAFAdIAGgdIAVAAIgRA+IAAAZg");
	this.shape_15.setTransform(-382.925,-5.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgUAsIAAhXIAUAAIAABDIAVAAIAAAUg");
	this.shape_16.setTransform(-388.25,-5.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWAsIAAhXIAVAAQAJAAAFADQAGADACAFQACAGAAAHIAAAIQAAAJgDAEQgDAGgGACQgGACgGAAIgBAAIAAAggAgCgEIABAAIACgBIABgEIAAgKIgBgEQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_17.setTransform(-393.325,-5.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgWAsIAAhXIAVAAQAJAAAFADQAGADACAFQACAGAAAHIAAAIQAAAJgDAEQgDAGgGACQgGACgGAAIgBAAIAAAggAgCgEIABAAIACgBIABgEIAAgKIgBgEQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_18.setTransform(-398.625,-5.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAGAsIgBgRIgJAAIgBARIgVAAIANhXIAcAAIALBXgAADAIIgDgXIAAgHIAAAHIgCAXIAFAAg");
	this.shape_19.setTransform(-404.2,-5.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAGgSIAGACIAFABQAEAAABgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgCgEAAgGQABgMAFgGQAGgHAKAAIAJABIAKAEIgGARIgFgCIgFgBQgDAAgBACQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAABABIAFAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgCAGQgDAFgGADQgFADgGAAIgLgBg");
	this.shape_20.setTransform(-410.75,-5.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgFATIgDglIARAAIgDAlg");
	this.shape_21.setTransform(-414.5,-7.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgPAnQgGgHAAgNIAAglQAAgNAGgHQAGgHAMAAIAKABIAIADIgHARIgEgCIgDAAIgBAAQgEAAgCADQgBACAAAFIAAAhQAAAFACACQACACAEAAIABAAIADAAIAEgBIAHAQIgJADIgKABQgMABgGgHg");
	this.shape_22.setTransform(-418.025,-5.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgXAoQgHgFAAgNIAAgKQAAgHADgDQADgEAFAAIgEgIIAAgGIAAgGQAAgIABgFQACgFAEgCQAFgDAIAAQAFAAAEADQAEACABAEQACAGAAAIIAAAFIgBAGQgBAEgDADQgCADgFABIAIALIgBgGIgBgFIARAAIAAALIgBAJQgBADgCAEIALARIgUAAIgCgDIgGADIgGABQgOABgGgGgAgKAOIAAACIAAAEQAAAEACACQACADAEAAIABAAIABgBIgKgQgAgGgaIAAADIAAAKIAAABIAAACIADgCQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAAAgBIAAgHIgBgDIgCgBIgCABg");
	this.shape_23.setTransform(-424.0517,-5.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgJAsIAAhDIgNAAIAAgUIAtAAIAAAUIgNAAIAABDg");
	this.shape_24.setTransform(-429.825,-5.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgIA4IAAhvIARAAIAABvg");
	this.shape_25.setTransform(-438.05,-3.825);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgLArQgFgDgDgFQgDgEAAgIIAAgLIAAgFIABgEIABgEIAIgVIAJgXIASAAIgHAQIgHARIACgBIABAAQAJAAAFAGQAFAGAAAKIAAALQAAAHgDAGQgDAGgEADQgGADgHAAQgGAAgFgCgAgBAEIgBABIAAATQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAAAIABAAIABAAIABgCIAAgTIgBgBIgBgBIgBABg");
	this.shape_26.setTransform(-446.6,-5.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLArQgGgDgCgFQgDgEAAgIIAAgLIAAgFIABgEIABgEIAIgVIAIgXIATAAIgHAQIgHARIABgBIABAAQALAAAEAGQAFAGAAAKIAAALQAAAHgDAGQgDAGgFADQgFADgHAAQgGAAgFgCgAAAAEIgBABIAAATQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIAAAAIABAAIABgCIAAgTIgBgBIgBgBIAAABg");
	this.shape_27.setTransform(-451.85,-5.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgVAtIAAgSIAMgPIAJgOQADgHAAgGIAAgBIgBgGQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAIgHABIgEABIgHgQIAJgEQAHgBAGAAQAHAAAFADQAGAFACAFQADAHAAAHIAAABQAAAGgDAGIgFALIgHAKIgHAJIATAAIAAATg");
	this.shape_28.setTransform(-457,-5.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAFgSIAHACIAGABQADAAABgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgBgEgBgGQAAgMAHgGQAFgHAJAAIAJABIALAEIgGARIgGgCIgDgBQgEAAgCACQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIAGAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgDAGQgDAFgFADQgFADgGAAIgLgBg");
	this.shape_29.setTransform(-463.25,-5.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgSAsIAAhXIAlAAIAAATIgTAAIAAAPIAQAAIAAASIgQAAIAAAQIATAAIAAATg");
	this.shape_30.setTransform(-467.6,-5.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgJAsIAAhXIATAAIAABXg");
	this.shape_31.setTransform(-471.25,-5.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AADAsIgGgiIgBAAIAAAiIgUAAIAAhXIAVAAQAJAAAGADQAGADACAFQACAGgBAHIAAAHQABAGgCAFQgCAEgDACIAKAngAgEgFIABAAQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAIABgEIAAgJIgBgEQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_32.setTransform(-475.45,-5.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgTAsIAAhXIAmAAIAAATIgTAAIAAAPIAQAAIAAASIgQAAIAAAQIATAAIAAATg");
	this.shape_33.setTransform(-480.35,-5.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgLAsIgKgDIAGgSIAGACIAFABQAEAAABgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBIAAAAQAAgDgCgDIgFgHIgEgDIgGgHQgDgDgBgFQgCgEAAgGQABgMAFgGQAGgHAKAAIAJABIAKAEIgGARIgFgCIgFgBQgDAAgBACQgBAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAABABIAFAGIACACIACACIAGAGIAFAIQABAFAAAGQAAAIgCAGQgDAFgGADQgFADgGAAIgLgBg");
	this.shape_34.setTransform(-485,-5.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-487.6,-14.2,1057.3000000000002,18.7);


(lib.ticket_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ticket();
	this.instance.setTransform(-4507,-706,7.0332,7.0332);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ticket_mc, new cjs.Rectangle(-4507,-706,2714.8,1462.9), null);


(lib.sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EAB3AggMAAAghBQAAhQghglQgggphFAAQgUAAgfADQgbACgZAFMAAAAjVIuLAAMAAAhA/IOLAAIAAQSIBVgFIBPAAQHVgDD9DfQD/DfADHrMAAAAiMg");
	this.shape.setTransform(2888.125,-161.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AJLd8QnRAAj6hsQj9huhdjQQhfjQAFktIAAzRIkPAAIAAs1IEPAAIAAtKIOKAAIAANKIHmAAIAAM1InmAAIAAPmQgDC8BYBEQBaBEDcgGIBjAAIAANUg");
	this.shape_1.setTransform(2666.2,-145.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AB3YaMAAAghBQAAhQghgmQgggohFAAQgXAAgeACQgeADgUAFMAAAAjVIuLAAMAAAgtvQEthdEWgyQEYg1DUAAQHVgCD9DfQD/DfADHrMAAAAiMg");
	this.shape_2.setTransform(2449.525,-109.8764);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAHY0IgFAAQnxADkCkZQkEkYgDpFIAAuGQADpEEEkXQECkWHxADIAFAAQHrgDECEWQECEXADJEIAAOGQgDJFkCEYQj/EWnlAAIgJAAgAhZqjQgZA/AACEIAAPBQAACFAZA8QAbA8BAgDIAFAAQA9gCAZg8QAWg9AAh/IAAvBQAAiCgWg8QgZg/g9gCIgFAAQhAAAgbA8g");
	this.shape_3.setTransform(2209.275,-107.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("EAKoAggMAAAgwtIgoHcMgEbApRIrOAAMgEbgpRIgoncMAAAAwtIucAAMAAAhA/IWnAAICKexIAUE9IAbk9ICT+xIWeAAMAAABA/g");
	this.shape_4.setTransform(1915.925,-161.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AnbYgQjTgWkThLIBQtoQC+BBCwAjQCvAmCeAAQCMACBUgbQBWgeAChOQADhBgrgoQgrgohqgtQgygXgzgUQgygWg3gXQlDiMijjyQilj2AAltQAAjxBijQQBkjQDNiCQDOiAE/gFQB+gFDZAZQDdAZDrBJIhLNFQiWgwiUgeQiUgeiWAAQhxAAg7AjQg+AjAAA/QAAA3AyAjQAuAjBiAtQAtAXAtAUQAtAWAyAXQDQBcCWB2QCZB2BTCsQBQCsADEFQACEYhuDkQhsDijzCFQj1CHmQACIgZABQh0AAjAgVg");
	this.shape_5.setTransform(1568.7028,-106.2792);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("EgHEAh4MAAAguuIOJAAMAAAAuugAk71BQhrh+AAjmQAAjXBrh+QBsh6DIgDQDIADBsB6QBrB+AADXQAADmhrB+QhsB9jIACQjIgChsh9g");
	this.shape_6.setTransform(1395.825,-170.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("EAB3AggMAAAghBQAAhQghglQgggphFAAQgUAAgfADQgbACgZAFMAAAAjVIuLAAMAAAhA/IOLAAIAAQSIBVgFIBPAAQHVgDD9DfQD/DfADHrMAAAAiMg");
	this.shape_7.setTransform(1206.875,-161.725);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("EgHcAggMAAAgyUIpIAAIAAurMAhJAAAIAAOrIpIAAMAAAAyUg");
	this.shape_8.setTransform(975.025,-161.725);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFE400").s().p("EgA9AheQhzgBiPgTQiRgViAgYQh/gXhEgUIjwtxQDNA+DLAoQDNAoCMAAQCSACBXgTQBVgXAjhaQAlhYgCjFIhnAAIgOAAQnyACkCkYQkFkZgCpEIAAq4QACprEFkeQEHkbH2ADIAFAAQDDAAERARQERASEUAZMAAAAvYQACJrkHEfQkCEcowAAIgKAAgAhOzPQgoA8ACC5IAALNQgCC5AjA6QAjA6BmgEIAPAAIAZAAIAUAAQAAlHAClLQADlKAAlJIgtAAIgFAAIgQAAQheAAglA6g");
	this.shape_9.setTransform(676.3012,-51.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFE400").s().p("EgHEAh4MAAAguuIOJAAMAAAAuugAk71BQhrh+AAjmQAAjXBrh+QBsh6DIgDQDIADBsB6QBrB+AADXQAADmhrB+QhsB9jIACQjIgChsh9g");
	this.shape_10.setTransform(492.525,-170.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFE400").s().p("EgRYAggMAAAhA/IQXAAQFJAAEABnQD/BpCRDhQCSDiACFoIAABnQADE3hnDNQhnDLjuBnQD4BVB5DRQB1DTAAFjIAAD9QgCFpiID1QiHD2jzB9Qj1B9lLAAgAieSbIA5AAQB6AAArg9QAqg5gChsIAAmdQAChzgog8Qgog9h/AAIg5AAgAienQIBIAAQB6AAArg8QAqg5gChsIAAj9QAChzgog8Qgog8h/AAIhIAAg");
	this.shape_11.setTransform(302.425,-161.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFE400").s().p("AB3YaMAAAghBQAAhQghgmQgggohFAAQgXAAgeACQgeADgUAFMAAAAjVIuLAAMAAAgtvQEthdEWgyQEYg1DUAAQHVgCD9DfQD/DfADHrMAAAAiMg");
	this.shape_12.setTransform(-14.025,-109.8764);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFE400").s().p("EgHEAh4MAAAguuIOJAAMAAAAuugAk71BQhrh+AAjmQAAjXBrh+QBsh6DIgDQDIADBsB6QBrB+AADXQAADmhrB+QhsB9jIACQjIgChsh9g");
	this.shape_13.setTransform(-203.025,-170.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFE400").s().p("EAC1AggMgC1gnFMgCzAnFIzOAAMgE0hA/IPxAAMAAwAx7MAETgx7IMDAAMAETAx7MAAwgx7IPxAAMgE0BA/g");
	this.shape_14.setTransform(-451.025,-161.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_caption_mc, new cjs.Rectangle(-2110.3,-478.6,6598.8,751.9000000000001), null);


(lib.second_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2ndprize();
	this.instance.setTransform(-45,-125,0.9529,0.9529);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.second_prize_mc, new cjs.Rectangle(-45,-125,264.9,235.4), null);


(lib.promo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.promo();
	this.instance.setTransform(-3677,-536,3.8791,3.8791);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.promo_mc, new cjs.Rectangle(-3677,-536,1078.4,1113.3), null);


(lib.other_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.consolation();
	this.instance.setTransform(-585,-862,15.692,15.692);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.other_prize_mc, new cjs.Rectangle(-585,-862,4174.1,1302.5), null);


(lib.daily_sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE400").s().p("AnbYgQjTgWkThLIBQtoQC+BBCwAjQCvAmCeAAQCMACBUgbQBWgeAChOQADhBgrgoQgrgohqgtQgygXgzgUQgygWg3gXQlDiMijjyQilj2AAltQAAjxBijQQBkjQDNiCQDOiAE/gFQB+gFDZAZQDdAZDrBJIhLNFQiWgwiUgeQiUgeiWAAQhxAAg7AjQg+AjAAA/QAAA3AyAjQAuAjBiAtQAtAXAtAUQAtAWAyAXQDQBcCWB2QCZB2BTCsQBQCsADEFQACEYhuDkQhsDijzCFQj1CHmQACIgZABQh0AAjAgVg");
	this.shape.setTransform(3815.2528,-106.2792);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFE400").s().p("AqoUSQk0kjgFpjIAAtTQgDpFD9kWQD9kTISACQHrgCDpETQDpEUgDJCIAALdIw+AAIAAChQAACMBrBQQBsBQDXADQBdAAB6gQQB7gMBigZIBOM1QjEArivAUQivAUh7AAIgKAAQokAAkxkigAg+rsQgZA6AACFIAADrIDmAAIAAjrQACiFgZg6QgZg6hBADIgGAAQg7AAgbA3g");
	this.shape_1.setTransform(3593.3751,-107.2501);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFE400").s().p("AuLXXIAAtOIM20MIryAAIAAtTIamAAIAANJIsnURINUAAIAANTg");
	this.shape_2.setTransform(3379.775,-103.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFE400").s().p("EgHEAh4MAAAguuIOJAAMAAAAuugAk71BQhrh+AAjmQAAjXBrh+QBsh6DIgDQDIADBsB6QBrB+AADXQAADmhrB+QhsB9jIACQjIgChsh9g");
	this.shape_3.setTransform(3207.775,-170.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFE400").s().p("ArsYaMAAAguzQCtgwEJgoQEKglErgDIHuAAIAANUInuAAIhSAAIhGAFMAAAAjag");
	this.shape_4.setTransform(3061.725,-109.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFE400").s().p("EgRHAggMAAAhA/IP0AAQHOACECCPQECCPBnECQBnECgFFfIAAFcQgDG+iWD0QiWD1kKBgQkJBhlZgFIg6AAIAAX9gAiNjdIAjAAQB6ADA1g6QA3g3gDiPIAAnCQADiIg1g8Qgyg8h/ADIgjAAg");
	this.shape_5.setTransform(2846.1866,-161.725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFE400").s().p("EAB3AggMAAAghBQAAhQghglQgggphFAAQgUAAgfADQgbACgZAFMAAAAjVIuLAAMAAAhA/IOLAAIAAQSIBVgFIBPAAQHVgDD9DfQD/DfADHrMAAAAiMg");
	this.shape_6.setTransform(2531.525,-161.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFE400").s().p("AnbYgQjTgWkThLIBQtoQC+BBCwAjQCvAmCeAAQCMACBUgbQBWgeAChOQADhBgrgoQgrgohqgtQgygXgzgUQgygWg3gXQlDiMijjyQilj2AAltQAAjxBijQQBkjQDNiCQDOiAE/gFQB+gFDZAZQDdAZDrBJIhLNFQiWgwiUgeQiUgeiWAAQhxAAg7AjQg+AjAAA/QAAA3AyAjQAuAjBiAtQAtAXAtAUQAtAWAyAXQDQBcCWB2QCZB2BTCsQBQCsADEFQACEYhuDkQhsDijzCFQj1CHmQACIgZABQh0AAjAgVg");
	this.shape_7.setTransform(2304.0528,-106.2792);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFE400").s().p("AsKU/QjwjxAAm9IAAgtQAAm/DwjsQDzjuHrgDIBIAAIBaAFIAAh2QAFi0hYhDQhUhEjiACQiJAAioAoQioAoijA/IDxtyQAqgUBngWQBpgaCCgTQCAgVB2AAQGQAADpB0QDrBzBiDpQBkDpgDFfIAAelQkWBJkEAtQkFAtkIADQnrgDjzjwgAg7FSQg3A1gDBxIAABSQADB+A3A5QA3A5BIAAIAyAAIAAofIgyAAQhIAAg3A3g");
	this.shape_8.setTransform(2074.428,-107);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFE400").s().p("EACMAhgQpQgDktk7Qktk+AAprIAA7xQAAprEtk+QEtk+JQAAIAFAAQDzAADIAqQDLArC5BVIlXL/QhNgXhbgKQhZgNhGAAIgIAAQi8AAhfB3QheBzAADeIAAY4QACDgB1BzQB1B1DCABIAEAAQBYAABVgSQBWgRBjgrIFWL8QjTBnjXA0QjbAykJAAg");
	this.shape_9.setTransform(1856.9,-162.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFE400").s().p("EgA6AgbQhzAAiSgUQiOgUiAgZQiAgXhGgUIjwtxQDNA+DNAoQDLAoCNAAQCTADBYgXQBUgWAjhaQAjhYAAjIIhNAFIhPAAQkHACjfhaQjfhYiKjaQiHjXgFl3IAA9vIOSAAIAAdWQAABQAgAoQAhAmBDAAQAZAAAZgDQAbgCAUgFIAFv+IAAvsIOLAAMAAAAuPQADJrkFEgQkEEbouAAIgKAAg");
	this.shape_10.setTransform(1545.8762,-45.2489);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFE400").s().p("EgHEAggMAAAhA/IOJAAMAAABA/g");
	this.shape_11.setTransform(1356.625,-161.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFE400").s().p("EgHEAh4MAAAguuIOJAAMAAAAuugAk71BQhrh+AAjmQAAjXBrh+QBsh6DIgDQDIADBsB6QBrB+AADXQAADmhrB+QhsB9jIACQjIgChsh9g");
	this.shape_12.setTransform(1224.825,-170.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFE400").s().p("AsKU/QjwjxAAm9IAAgtQAAm/DwjsQDzjuHrgDIBIAAIBaAFIAAh2QAFi0hYhDQhUhEjiACQiJAAioAoQioAoijA/IDxtyQAqgUBngWQBpgaCCgTQCAgVB2AAQGQAADpB0QDrBzBiDpQBkDpgDFfIAAelQkWBJkEAtQkFAtkIADQnrgDjzjwgAg7FSQg3A1gDBxIAABSQADB+A3A5QA3A5BIAAIAyAAIAAofIgyAAQhIAAg3A3g");
	this.shape_13.setTransform(1036.328,-107);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFE400").s().p("EgRMAggMAAAhA/IP+AAQFRACEKCUQEJCRCZEUQCbERADF9IAAaUQgDGCiZEZQibEWkHCYQkJCXlPACgAiSSbIAjAAQCTACArhEQAqhDgFirIAA8FQAAigg3gyQg3gyh1AFIgjAAg");
	this.shape_14.setTransform(793.325,-161.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("EACOAggIlMz9IAAT9IuKAAMAAAhA/IOKAAMAAAAkJIEbxtIOZAAIm5VZIIMZKg");
	this.shape_15.setTransform(481.15,-161.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Ao6fLQjxiUiHkHQiFkHgClhIAA+KQAClkCFkJQCHkHDxiUQDziRFHgDQFIADDzCRQDwCUCIEHQCFEJACFkIAAeKQgCFhiFEHQiIEHjwCUQjzCRlIADQlHgDjziRgAhPy6QgcAhAAA+MAAAAi+QACA9AaAZQAZAbAcAFQAZAIABgDQBsAAAAh7MAAAgi+QgDg5gZgcQgZgcgbgHIgcgIQg2AAgZAhg");
	this.shape_16.setTransform(227.45,-162.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Aonf/QkChBjxiDIFXsEQBaBHCDA1QB/A3CrACQCUgFA7hnQA8hmgDibIAAlYQADhxgjhuQgjhrhmhJQhkhGjJgFQiCAFh4ArQh7AqhaAyMADzgkTIYzAAIAANyIprAAIg5IaQFoAbDEEbQDDEcADIgIAAH4QgFInkgEvQkgEtn0AFQkKgBj/hAgAgGqeIgEAAIAEAAIAvgFIgFgFIgqAKIAAAAg");
	this.shape_17.setTransform(-26.925,-158.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("EgRMAggMAAAhA/IP+AAQFRACEKCUQEJCRCZEUQCbERADF9IAAaUQgDGCiZEZQibEWkHCYQkJCXlPACgAiSSbIAjAAQCTACArhEQAqhDgFirIAA8FQAAigg3gyQg3gyh1AFIgjAAg");
	this.shape_18.setTransform(-344.975,-161.725);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("EgOYAggMAAAhA/IcnAAIAAN3ItuAAIAALEILLAAIAAN7IrLAAIAAMTIN3AAIAAN2g");
	this.shape_19.setTransform(-567.7,-161.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("EAEzAggIhLsrInPAAIhLMrIumAAMAIkhA/IVpAAMAIkBA/gACLF+Ih2xcIgVlaIgUFaIh2RcIEVAAg");
	this.shape_20.setTransform(-809.525,-161.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.daily_sub_caption_mc, new cjs.Rectangle(-1811.4,-478.6,6598.700000000001,751.9000000000001), null);


(lib.cta_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cta();
	this.instance.setTransform(-556,-660,15.9471,15.9471);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_mc, new cjs.Rectangle(-556,-660,3891.1,749.5), null);


(lib.bt_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-6097,-219,14.3127,14.3127);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bt_logo, new cjs.Rectangle(-6097,-219,1574.3999999999996,901.7), null);


// stage content:
(lib.bigticketawarenesshtml5970x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// footer
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(452.4,85.9,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(283));

	// logo
	this.instance_1 = new lib.bt_logo();
	this.instance_1.setTransform(484.95,25.9,0.0767,0.0767,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(250).to({alpha:0},16).wait(17));

	// cta
	this.instance_2 = new lib.cta_mc();
	this.instance_2.setTransform(484.95,58.25,0.0538,0.0538,0,0,0,0,1.9);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(266).to({_off:false},0).wait(1).to({regX:1389.5,regY:-285.2,x:559.75,y:42.75,alpha:0.0032},0).wait(1).to({alpha:0.0145},0).wait(1).to({y:42.65,alpha:0.0371},0).wait(1).to({y:42.5,alpha:0.077},0).wait(1).to({y:42.3,alpha:0.1467},0).wait(1).to({y:41.9,alpha:0.2672},0).wait(1).to({y:41.4,alpha:0.4164},0).wait(1).to({y:40.9,alpha:0.5648},0).wait(1).to({y:40.45,alpha:0.6887},0).wait(1).to({y:40.15,alpha:0.7859},0).wait(1).to({y:39.9,alpha:0.8625},0).wait(1).to({y:39.7,alpha:0.9229},0).wait(1).to({y:39.55,alpha:0.9628},0).wait(1).to({y:39.45,alpha:0.9857},0).wait(1).to({alpha:0.9969},0).wait(1).to({regX:0,regY:1,x:484.95,y:54.9,alpha:1},0).wait(1));

	// ticket
	this.instance_3 = new lib.ticket_mc();
	this.instance_3.setTransform(363,42.7,0.0748,0.0748,0,0,0,0,0.7);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(250).to({_off:false},0).wait(1).to({regX:-3149.6,regY:25.5,x:127.8,y:44.55,alpha:0.0032},0).wait(1).to({x:129.2,alpha:0.0145},0).wait(1).to({x:131.95,alpha:0.0371},0).wait(1).to({x:136.8,alpha:0.077},0).wait(1).to({x:145.3,y:44.6,alpha:0.1467},0).wait(1).to({x:160,y:44.65,alpha:0.2672},0).wait(1).to({x:178.2,y:44.7,alpha:0.4164},0).wait(1).to({x:196.3,y:44.75,alpha:0.5648},0).wait(1).to({x:211.4,y:44.8,alpha:0.6887},0).wait(1).to({x:223.25,y:44.85,alpha:0.7859},0).wait(1).to({x:232.6,alpha:0.8625},0).wait(1).to({x:240,y:44.9,alpha:0.9229},0).wait(1).to({x:244.85,alpha:0.9628},0).wait(1).to({x:247.65,alpha:0.9857},0).wait(1).to({x:249,y:44.95,alpha:0.9969},0).wait(1).to({regX:0,regY:0,x:484.95,y:43.1,alpha:1},0).wait(17));

	// main_sub_caption
	this.instance_4 = new lib.sub_caption_mc();
	this.instance_4.setTransform(484.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(15).to({_off:false},0).wait(1).to({regX:1183.9,regY:-112.5,x:595.6,y:51.75,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({y:51.7,alpha:0.0435},0).wait(1).to({y:51.6,alpha:0.0919},0).wait(1).to({y:51.45,alpha:0.1816},0).wait(1).to({y:51.15,alpha:0.3248},0).wait(1).to({y:50.85,alpha:0.4878},0).wait(1).to({y:50.55,alpha:0.6345},0).wait(1).to({y:50.35,alpha:0.7499},0).wait(1).to({y:50.2,alpha:0.8388},0).wait(1).to({y:50.05,alpha:0.9088},0).wait(1).to({y:49.95,alpha:0.9564},0).wait(1).to({y:49.9,alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:60.5,alpha:1},0).wait(61).to({regX:1183.9,regY:-112.5,x:595.6,y:49.9,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({y:49.95,alpha:0.9565},0).wait(1).to({y:50.05,alpha:0.9081},0).wait(1).to({y:50.2,alpha:0.8184},0).wait(1).to({y:50.5,alpha:0.6752},0).wait(1).to({y:50.8,alpha:0.5122},0).wait(1).to({y:51.1,alpha:0.3655},0).wait(1).to({y:51.3,alpha:0.2501},0).wait(1).to({y:51.45,alpha:0.1612},0).wait(1).to({y:51.6,alpha:0.0912},0).wait(1).to({y:51.7,alpha:0.0436},0).wait(1).to({y:51.75,alpha:0.0166},0).wait(1).to({alpha:0.0036},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:62.4,alpha:0},0).to({_off:true},1).wait(177));

	// other_prize
	this.instance_5 = new lib.other_prize_mc();
	this.instance_5.setTransform(484.95,72.95,0.0689,0.0689,0,0,0,0,0.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(173).to({_off:false},0).wait(1).to({regX:1502,regY:-210.8,x:588.4,y:58.35,alpha:0.0037},0).wait(1).to({y:58.15,alpha:0.0167},0).wait(1).to({y:57.8,alpha:0.0435},0).wait(1).to({y:57.2,alpha:0.0919},0).wait(1).to({y:56.05,alpha:0.1816},0).wait(1).to({y:54.25,alpha:0.3248},0).wait(1).to({y:52.2,alpha:0.4878},0).wait(1).to({y:50.3,alpha:0.6345},0).wait(1).to({y:48.85,alpha:0.7499},0).wait(1).to({y:47.7,alpha:0.8388},0).wait(1).to({y:46.85,alpha:0.9088},0).wait(1).to({y:46.25,alpha:0.9564},0).wait(1).to({y:45.9,alpha:0.9834},0).wait(1).to({y:45.7,alpha:0.9964},0).wait(1).to({regX:0,regY:0.8,x:484.95,y:60.25,alpha:1},0).wait(63).to({regX:1502,regY:-210.8,x:588.5,y:45.65,alpha:0.9968},0).wait(1).to({x:588.9,alpha:0.9855},0).wait(1).to({x:589.75,alpha:0.9629},0).wait(1).to({x:591.25,alpha:0.923},0).wait(1).to({x:593.9,y:45.6,alpha:0.8533},0).wait(1).to({x:598.45,y:45.55,alpha:0.7328},0).wait(1).to({x:604.05,y:45.5,alpha:0.5836},0).wait(1).to({x:609.65,y:45.4,alpha:0.4352},0).wait(1).to({x:614.3,y:45.35,alpha:0.3113},0).wait(1).to({x:617.95,y:45.3,alpha:0.2141},0).wait(1).to({x:620.85,alpha:0.1375},0).wait(1).to({x:623.1,y:45.25,alpha:0.0771},0).wait(1).to({x:624.65,alpha:0.0372},0).wait(1).to({x:625.5,alpha:0.0143},0).wait(1).to({x:625.9,alpha:0.0031},0).wait(1).to({regX:0,regY:0.8,x:522.6,y:59.8,alpha:0},0).wait(17));

	// second_prize_mc
	this.instance_6 = new lib.second_prize_mc();
	this.instance_6.setTransform(240.05,56.15,0.3813,0.3813);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(98).to({_off:false},0).wait(1).to({regX:87.5,regY:-7.3,x:273.4,y:53.3,alpha:0.0037},0).wait(1).to({y:53.2,alpha:0.0167},0).wait(1).to({y:52.95,alpha:0.0435},0).wait(1).to({y:52.55,alpha:0.0919},0).wait(1).to({y:51.8,alpha:0.1816},0).wait(1).to({y:50.6,alpha:0.3248},0).wait(1).to({y:49.25,alpha:0.4878},0).wait(1).to({y:48,alpha:0.6345},0).wait(1).to({y:47.05,alpha:0.7499},0).wait(1).to({y:46.3,alpha:0.8388},0).wait(1).to({y:45.7,alpha:0.9088},0).wait(1).to({y:45.3,alpha:0.9564},0).wait(1).to({y:45.05,alpha:0.9834},0).wait(1).to({y:44.95,alpha:0.9964},0).wait(1).to({regX:0,regY:0,x:240.05,y:47.75,alpha:1},0).wait(170));

	// su_sub_caption
	this.instance_7 = new lib.daily_sub_caption_mc();
	this.instance_7.setTransform(484.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(98).to({_off:false},0).wait(1).to({regX:1488.9,regY:-112.5,x:624.2,y:51.75,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({y:51.7,alpha:0.0435},0).wait(1).to({y:51.6,alpha:0.0919},0).wait(1).to({y:51.45,alpha:0.1816},0).wait(1).to({y:51.15,alpha:0.3248},0).wait(1).to({y:50.85,alpha:0.4878},0).wait(1).to({y:50.55,alpha:0.6345},0).wait(1).to({y:50.35,alpha:0.7499},0).wait(1).to({y:50.2,alpha:0.8388},0).wait(1).to({y:50.05,alpha:0.9088},0).wait(1).to({y:49.95,alpha:0.9564},0).wait(1).to({y:49.9,alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:60.5,alpha:1},0).wait(61).to({regX:1488.9,regY:-112.5,x:624.2,y:49.9,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({y:49.95,alpha:0.9565},0).wait(1).to({y:50.05,alpha:0.9081},0).wait(1).to({y:50.2,alpha:0.8184},0).wait(1).to({y:50.5,alpha:0.6752},0).wait(1).to({y:50.8,alpha:0.5122},0).wait(1).to({y:51.1,alpha:0.3655},0).wait(1).to({y:51.3,alpha:0.2501},0).wait(1).to({y:51.45,alpha:0.1612},0).wait(1).to({y:51.6,alpha:0.0912},0).wait(1).to({y:51.7,alpha:0.0436},0).wait(1).to({y:51.75,alpha:0.0166},0).wait(1).to({alpha:0.0036},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:62.4,alpha:0},0).wait(95));

	// promo
	this.instance_8 = new lib.promo_mc();
	this.instance_8.setTransform(511.25,43.5,0.078,0.078,0,0,0,1.3,0.7);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regX:-3137.8,regY:20.7,x:266.15,y:45.05,alpha:0.0037},0).wait(1).to({x:265.8,alpha:0.0167},0).wait(1).to({x:265.1,alpha:0.0435},0).wait(1).to({x:263.8,alpha:0.0919},0).wait(1).to({x:261.45,alpha:0.1816},0).wait(1).to({x:257.7,alpha:0.3248},0).wait(1).to({x:253.4,alpha:0.4878},0).wait(1).to({x:249.55,alpha:0.6345},0).wait(1).to({x:246.5,alpha:0.7499},0).wait(1).to({x:244.15,alpha:0.8388},0).wait(1).to({x:242.3,alpha:0.9088},0).wait(1).to({x:241.05,alpha:0.9564},0).wait(1).to({x:240.35,alpha:0.9834},0).wait(1).to({x:240,alpha:0.9964},0).wait(1).to({regX:0,regY:0.7,x:484.95,y:43.5,alpha:1},0).wait(83).to({alpha:0},15).to({_off:true},1).wait(169));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5050F").s().p("EhM1AHLIAAuVMCZrAAAIAAOVg");
	this.shape.setTransform(485.075,45.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(283));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(478.3,34.9,498.59999999999997,68.4);
// library properties:
lib.properties = {
	id: '8F9B67423E0CC34A8BA2D26890153A40',
	width: 970,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_18.jpg", id:"_18"},
		{src:"images/_2ndprize.jpg", id:"_2ndprize"},
		{src:"images/consolation.jpg", id:"consolation"},
		{src:"images/cta.jpg", id:"cta"},
		{src:"images/logo.jpg", id:"logo"},
		{src:"images/promo.jpg", id:"promo"},
		{src:"images/ticket.jpg", id:"ticket"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F9B67423E0CC34A8BA2D26890153A40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;