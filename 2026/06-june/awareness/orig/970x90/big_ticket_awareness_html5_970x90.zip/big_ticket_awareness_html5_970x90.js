(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._2ndprize = function() {
	this.initialize(img._2ndprize);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,288,287);


(lib._970x90 = function() {
	this.initialize(img._970x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,970,90);


(lib.bigwin = function() {
	this.initialize(img.bigwin);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,288,287);


(lib.cta = function() {
	this.initialize(img.cta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,204,40);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,200,94);


(lib.promo = function() {
	this.initialize(img.promo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,288,287);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.third_sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDcQhhhLAAiSQAAiEBhhRQBfhSCQAAQCRAABfBSQBhBRAACEQAACShhBLQhfBNiRAAQiQAAhfhNg");
	this.shape.setTransform(2027.375,-98.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABUUUIjrypIAASpIpUAAMAAAgonIJUAAIAASiIDoyiIJyAAIlATLIFpVcg");
	this.shape_1.setTransform(1902.825,-202.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIomAAIAAG7IG/AAIAAIsIm/AAIAAHsIIsAAIAAIqg");
	this.shape_2.setTransform(1754.4,-202.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIomAAIAAG7IG+AAIAAIsIm+AAIAAHsIIsAAIAAIqg");
	this.shape_3.setTransform(1626.45,-202.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABxUUIhx4bIhwYbIsAAAMgDBgonIJ3AAIAefMICs/MIHhAAICsfMIAe/MIJ3AAMgDAAong");
	this.shape_4.setTransform(1445.5,-202.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AkpUUIAAriInx9FIJoAAIC1NkICxtkIJnAAInwdFIAALig");
	this.shape_5.setTransform(1207.275,-202.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABrUUIjPvfIgqAAIAAPfIpVAAMAAAgonIJ/AAQGcAACjC4QChC5AAFhIAAC5QAAF9jACmIEoR5gAiOiqIAdAAQBNAAAfgkQAggjAAhWIAAj6QAAhXgggkQgfgihNAAIgdAAg");
	this.shape_6.setTransform(1041.075,-202.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAIsIm9AAIAAHsIIrAAIAAIqg");
	this.shape_7.setTransform(896.75,-202.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AmPUUMgGbgonIJ3AAIC2clICx8lIJ3AAMgGaAong");
	this.shape_8.setTransform(742.05,-202.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAIsIm9AAIAAHsIIrAAIAAIqg");
	this.shape_9.setTransform(593.8,-202.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AjvDcQhhhLAAiSQAAiEBhhRQBfhSCQAAQCRAABfBSQBhBRAACEQAACShhBLQhfBNiRAAQiQAAhfhNg");
	this.shape_10.setTransform(441.675,-98.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AqGS+ICboWQD+BiBsAAQDSAAAAijIAAgRQAAhKg0hPQgzhRiBiAIhxhuQi3i0hQicQhQicAAj0IAAgGQAAlTCui/QCti/EzgBQD6AAEqB4IiZH0Qi+g5hZAAQjMAAgBClIAAAJQAAAYAIAWQAIAWALAUQALATAXAcIAoAwIA3A5IA6A/QBQBWAqAnQC8C9BTCYQBSCXAAEHIAAADQAAFgi6DJQi4DJkyAAQk0gBk1h8g");
	this.shape_11.setTransform(330.6,-203.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ABrUUIjPvfIgqAAIAAPfIpVAAMAAAgonIJ/AAQGcAACjC4QChC5AAFhIAAC5QAAF9jACmIEoR5gAiOiqIAdAAQBNAAAfgkQAggjAAhWIAAj6QAAhXgggkQgfgihNAAIgdAAg");
	this.shape_12.setTransform(179.275,-202.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAIsIm9AAIAAHsIIrAAIAAIqg");
	this.shape_13.setTransform(35,-202.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHUUIil5wIAAZwIpVAAMAAAgonIMRAAICfZIIAA5IIJSAAMAAAAong");
	this.shape_14.setTransform(-118.8,-202.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgHUUIil5wIAAZwIpVAAMAAAgonIMRAAICeZIIAA5IIJTAAMAAAAong");
	this.shape_15.setTransform(-291.95,-202.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_16.setTransform(-417.925,-202.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABxUUIhx4bIhvYbIsCAAMgDAgonIJ3AAIAefMICs/MIHhAAICsfMIAe/MIJ3AAMgDBAong");
	this.shape_17.setTransform(-571.15,-202.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABxUUIhx4bIhvYbIsCAAMgDAgonIJ3AAIAefMICs/MIHhAAICsfMIAe/MIJ3AAMgDBAong");
	this.shape_18.setTransform(-840.45,-202.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIomAAIAAG7IG/AAIAAIsIm/AAIAAHsIIsAAIAAIqg");
	this.shape_19.setTransform(-1015,-202.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgIUUIik5wIAAZwIpVAAMAAAgonIMSAAICdZIIAA5IIJTAAMAAAAong");
	this.shape_20.setTransform(-1168.8,-202.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.third_sub_caption_mc, new cjs.Rectangle(-1261.7,-403.1,3503.3,474.8), null);


(lib.sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkfEIQh1haAAivQAAifB1hhQByhiCtAAQCuAABzBiQB0BhAACfQAACvh0BaQhzBciuAAQitAAhyhcg");
	this.shape.setTransform(3312.275,-64.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AsHWyIC6qDQEwB3CCAAQD8AAAAjEIAAgUQAAhZg9hfQg/hgibiaIiHiEQjbjZhgi7Qhgi6AAklIAAgIQAAmYDQjlQDPjlFxAAQEtAAFlCPIi5JZQjihGhsAAQj1AAAADIIAAALQAAAcAJAaQAKAbANAYQANAXAbAhQAeAkATAVIBCBFIBFBLQBhBoAyAvQDhDiBkC2QBiC2AAE8IAAAEQAAGmjeDxQjeDwlvAAQlyAAlyiUg");
	this.shape_1.setTransform(3179,-190.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqyYYMAAAgwvIVeAAIAAKZIqTAAIAAIUIIXAAIAAKbIoXAAIAAJOIKaAAIAAKZg");
	this.shape_2.setTransform(3024.675,-189.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_3.setTransform(2896.75,-189.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AlkYYMAAAglvIm4AAIAArAIY4AAIAALAIm1AAMAAAAlvg");
	this.shape_4.setTransform(2767.9,-189.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_5.setTransform(2639,-189.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ArZYYMAAAgwvILMAAMAAAAlvILnAAIAALAg");
	this.shape_6.setTransform(2503.375,-189.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_7.setTransform(2371.6,-189.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AtCYYMAAAgwvIMRAAQGIAADlC8QDlC+AAGEIAABNQAADzhMCSQhOCViwBNQFsCCAAIDIAAC+QAAGQjbDUQjfDWl5AAgAh2N0IArAAQBYAAAfgpQAigoAAhaIAAkyQAAhegggpQgegshbAAIgrAAgAh2lbIA2AAQBXAAAjgoQAfgpAAhYIAAi8QAAhcgegsQgfgphcAAIg2AAg");
	this.shape_8.setTransform(2231.1,-189.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_9.setTransform(2088.85,-189.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AsHWyIC6qDQExB3CBAAQD9AAAAjEIAAgUQAAhZg/hfQg/hgiZiaIiHiEQjdjZhfi7Qhgi6AAklIAAgIQAAmYDQjlQDPjlFxAAQEtAAFlCPIi4JZQjjhGhrAAQj2AAAADIIAAALQAAAcAJAaQAKAbANAYQANAXAcAhQAeAkATAVIBBBFIBGBLQBfBoAzAvQDhDiBkC2QBiC2AAE8IAAAEQAAGmjeDxQjdDwlwAAQlyAAlyiUg");
	this.shape_10.setTransform(1960.25,-190.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AsHWyIC6qDQEwB3CCAAQD9AAAAjEIAAgUQgBhZg9hfQg/hgibiaIiHiEQjcjZhfi7Qhgi6AAklIAAgIQAAmYDRjlQDOjlFyAAQEsAAFlCPIi5JZQjihGhsAAQj1AAAADIIAAALQAAAcAJAaQAKAbANAYQANAXAbAhQAeAkAUAVIBBBFIBGBLQBgBoAyAvQDhDiBkC2QBiC2AAE8IAAAEQAAGmjeDxQjeDwlvAAQlyAAlyiUg");
	this.shape_11.setTransform(1797.5,-190.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AADZGQmbAAjSjdQjTjgABmfIAA3NQAAmuDYjaQDYjaGMAAIAHAAQGXAADQDgQDPDfAAGjIAAXNQABGujXDYQjUDWmJAAgAhgsdIAAY/QAACEBgAAIADAAQBgAAAAiEIAA4/QAAiGhjAAIgEAAQhcAAAACGg");
	this.shape_12.setTransform(1621.75,-190.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("As1YYMAAAgwvIL3AAQHvAADDDeQDCDdAAGnIAAEFQAAHYjmC5QjlC6mpAAIgrAAIAAR9gAhpinIAcAAQBbAAAlgpQAogsAAhnIAAlSQAAhngogsQglgphbAAIgcAAg");
	this.shape_13.setTransform(1433.6,-189.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("As9LlIAA3JQAAmQEEjrQEBjrGXAAQF9AAFiDGIkCJnQi1hhjUAAQkWAAADE4IAAVYQAACTBuAAQAzAAAegTIAAxmIKkAAIAAY8QjWB6ifA0QigA1jVAAQtWAAAAtmg");
	this.shape_14.setTransform(1202.4,-189.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_15.setTransform(1060.65,-189.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AtCYYMAAAgwvIMSAAQGHAADlC8QDlC+AAGEIAABNQABDzhNCSQhOCViwBNQFsCCAAIDIAAC+QAAGQjbDUQjfDWl5AAgAh2N0IArAAQBYAAAfgpQAigoAAhaIAAkyQAAhegggpQgegshbAAIgrAAgAh2lbIA2AAQBYAAAigoQAfgpAAhYIAAi8QAAhcgegsQgfgphcAAIg2AAg");
	this.shape_16.setTransform(920.15,-189.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AkfEIQh1haAAivQAAifB1hhQByhiCtAAQCuAABzBiQB0BhAACfQAACvh0BaQhzBciuAAQitAAhyhcg");
	this.shape_17.setTransform(723.225,-64.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AlkYYMAAAglvIm3AAIAArAIY4AAIAALAIm2AAMAAAAlvg");
	this.shape_18.setTransform(589.65,-189.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AqyYYMAAAgwvIVeAAIAAKZIqTAAIAAIUIIXAAIAAKbIoXAAIAAJOIKaAAIAAKZg");
	this.shape_19.setTransform(435.125,-189.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("ABmYYIkb2XIAAWXIrMAAMAAAgwvILMAAIAAWQIEW2QILwAAImBXBIGyZug");
	this.shape_20.setTransform(256.95,-189.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABrZJQm6AAjkjuQjjjvAAnSIAA0yQAAnSDjjvQDkjvG6AAIAEAAQFSAAEbCAIkBJAQhvghiHAAIgEAAQkaAAAAFWIAASoQgBChBYBbQBYBaCTAAIAEAAQB+AACOg7ID+I/Qk4CalwAAg");
	this.shape_21.setTransform(76.55,-189.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_22.setTransform(-61.3,-189.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AlkYYMAAAglvIm3AAIAArAIY4AAIAALAIm3AAMAAAAlvg");
	this.shape_23.setTransform(-190.2,-189.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("As8LlIAA3JQAAmQEDjrQEBjrGXAAQF9AAFiDGIkCJnQi1hhjTAAQkYAAAEE4IAAVYQAACTBuAAQAzAAAegTIAAxmIKkAAIAAY8QjWB6ifA0QihA1jTAAQtXAAABtmg");
	this.shape_24.setTransform(-409.3,-189.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AllYYMAAAgwvILLAAMAAAAwvg");
	this.shape_25.setTransform(-551.05,-189.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AtCYYMAAAgwvIMRAAQGIAADlC8QDmC+AAGEIAABNQAADzhOCSQhNCViwBNQFsCCAAIDIAAC+QAAGQjcDUQjdDWl6AAgAh2N0IArAAQBXAAAhgpQAhgoAAhaIAAkyQAAhegggpQgegshbAAIgrAAgAh2lbIA2AAQBYAAAhgoQAggpABhYIAAi8QgBhcgegsQgggphbAAIg2AAg");
	this.shape_26.setTransform(-691.55,-189.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_caption_mc, new cjs.Rectangle(-2010.4,-428.5,6598.799999999999,567.2), null);


(lib.second_prize_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._2ndprize();
	this.instance.setTransform(-41,-121,0.9244,0.9244);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.second_prize_mc, new cjs.Rectangle(-41,-121,266.3,265.3), null);


(lib.promo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.promo();
	this.instance.setTransform(-3677,-540,3.8791,3.8791);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.promo_mc, new cjs.Rectangle(-3677,-540,1117.1999999999998,1113.3), null);


(lib.other_prizes_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bigwin();
	this.instance.setTransform(187.7,-19.7,0.3635,0.3635);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.other_prizes_mc, new cjs.Rectangle(187.7,-19.7,104.69999999999999,104.4), null);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhMmBH3MAAAiPtMCZNAAAMAAACPtg");
	mask.setTransform(490.275,459.85);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqZeNQkHhuihilQiiilhEjCQhDjFAAiiQAAirAtiNQAtiNBPh0QBPh0BjhgQBdhbB3haQj0jFhyjAQh1i/AAksQAAjhBdjSQBejRCqibQCoibDxhdQDyhdEkAAQFYAAD2BjQD2BjCeCYQCfCZBGC8QBGC9AAC7QABEPiRDqQiQDrjXCGQFCDQCMDmQCKDlAAEyQgBD/hXDUQhYDUiuCeQixCfkGBYQkIBXlWAAQmMAAkGhugAnLIOQhsCgAADcQAABFAfBRQAfBSBEBEQBEBEBsAuQBsAtCXAAQElAACIiOQCIiNgBiwQABiDg8hlQg7hnhmhMQhlhMiLg8QiMg8icgyQieB3hrCegAjY0sQhaAng8BBQg8BCgcBIQgcBJAABEQAAC1CFCdQCECeFCBxQC0hxBgiTQBhiTAAjVQAAg+gZhHQgahFg7g/Qg7g9hbgsQhagqiCAAQh9AAhZAog");
	this.shape.setTransform(573.95,459.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABjemMAAAgsDQimBwjUBfQjMBajKBHIj/qKQChhDC1hZQCzhZCohnQCshqCYhzQCeh0B6iCIJMAAMAAAA9Mg");
	this.shape_1.setTransform(271.85,460.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AlkSaIAAtOIr7AAIAAqXIL7AAIAAtNILJAAIAANNIL7AAIAAKXIr7AAIAANOg");
	this.shape_2.setTransform(868.5,449.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EgZuBCNQs5lep9p9Qp9p9lds5QlqtWAAumQAAulFqtXQFds5J9p8QJ9p9M5leQNXlqOkAAQK9ABKXDOQKBDHIwF5QIoF1GpIBQGsIFEGJmIrHAAQj2neltmOQltmMnHkdQnQkioKiYQobido1ABQsiAArfE2QrFEtokIkQokIjksLGQk4LeAAMjQAAMiE4LgQEsLFIkIkQIkIkLFEtQLfE3MiAAQJVAAI0iuQIjioHfk/QHXk7FumyQFxm1DloJIK2AAQjxKQmsIsQmoIno2GSQo9GXqaDYQqwDfraABQulgBtWlpg");
	this.shape_3.setTransform(445.7,459.85);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,980.6,919.7), null);


(lib.daily_sub_caption_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAIsIm9AAIAAHsIIrAAIAAIqg");
	this.shape.setTransform(2353.75,-181.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABrUUIjPvfIgqAAIAAPfIpVAAMAAAgonIJ/AAQGcAACjC4QChC5AAFhIAAC6QAAF8jACmIEoR5gAiOirIAdAAQBNABAfglQAggiAAhWIAAj6QAAhWggglQgfgihNAAIgdAAg");
	this.shape_1.setTransform(2203.125,-181.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_2.setTransform(2080.075,-181.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ADAUUIgvn7IkhAAIgvH7IpIAAMAFXgonINhAAMAFXAongAgMnLIhKK6ICtAAIhKq6IgMjYg");
	this.shape_3.setTransform(1956.675,-181.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIUUIik5wIAAZwIpUAAMAAAgonIMRAAICdZIIAA5IIJUAAMAAAAong");
	this.shape_4.setTransform(1786.1,-181.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AACU6QlWAAivi4Qivi6AAlbIAAzVQAAlmC0i2QC0i1FKAAIAFAAQFUAACuC5QCsC7AAFdIAATVQAAFniyC0QixCylHAAgAhQqZIAAU2QAABtBQAAIACAAQBQAAAAhtIAA02QAAhvhSAAIgDAAQhNAAAABvg");
	this.shape_5.setTransform(1620.825,-181.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_6.setTransform(1502.675,-181.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ApfUUMAAAgonIJUAAIAAfcIJrAAIAAJLg");
	this.shape_7.setTransform(1389.725,-181.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ApfUUMAAAgonIJUAAIAAfcIJrAAIAAJLg");
	this.shape_8.setTransform(1245.775,-181.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_9.setTransform(1135.925,-181.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AGpUUIAA+cIgbEpIivZzInAAAIix5zIgZkpIAAecIpCAAMAAAgonIOJAAIBWTQIANDEIAQjEIBczQIODAAMAAAAong");
	this.shape_10.setTransform(986.375,-181.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ADAUUIgvn7IkhAAIgvH7IpIAAMAFXgonINhAAMAFXAongAgMnLIhKK6ICtAAIhKq6IgMjYg");
	this.shape_11.setTransform(750.575,-181.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIomAAIAAG7IG/AAIAAIsIm/AAIAAHsIIsAAIAAIqg");
	this.shape_12.setTransform(564.15,-181.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Aq3UUMAAAgonIKPAAQFGAAC/CcQC/CfAAFEIAABAQAADKhAB6QhBB7iTBBQEwBsAAGtIAACeQAAFNi3CyQi5Cyk7AAgAhiLgIAkAAQBIAAAbgiQAcghAAhLIAAj/QAAhOgbgjQgZgkhLAAIgkAAgAhikhIAtAAQBJAAAcgiQAagiAAhKIAAicQAAhMgZglQgagihMAAIgtAAg");
	this.shape_13.setTransform(419.325,-181.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AACU6QlWAAivi4Qivi6AAlbIAAzVQAAlmC0i2QC0i1FKAAIAFAAQFUAACuC5QCsC7AAFdIAATVQAAFniyC0QixCylHAAgAhQqZIAAU2QAABtBQAAIACAAQBQAAAAhtIAA02QAAhvhSAAIgDAAQhNAAAABvg");
	this.shape_14.setTransform(219.775,-181.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AkoUUIAA/cIlvAAIAApLIUvAAIAAJLIltAAIAAfcg");
	this.shape_15.setTransform(73.125,-181.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AqFS+ICaoWQD+BiBsAAQDSAAAAijIAAgRQAAhJgzhQQg0hQiBiBIhxhuQi3i0hQicQhQicAAjzIAAgHQAAlUCui+QCsi/E0AAQD7AAEpB3IiZH1Qi+g7hZAAQjNAAABCnIAAAJQgBAXAJAWQAHAWALAUQALATAXAdIAoAvIA3A5IA6A/QBQBWAqAnQC8C9BTCXQBRCYAAEHIAAADQABFhi5DIQi5DIkyAAQk0ABk0h9g");
	this.shape_16.setTransform(-104.3,-181.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AkpUUIAArhInx9GIJoAAIC1NkICxtkIJnAAInwdGIAALhg");
	this.shape_17.setTransform(-254.875,-181.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ADAUUIgvn7IkhAAIgvH7IpIAAMAFXgonINhAAMAFXAongAgMnLIhKK6ICtAAIhKq6IgMjYg");
	this.shape_18.setTransform(-421.575,-181.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ABxUUIhx4bIhvYbIsCAAMgDAgonIJ3AAIAefNICs/NIHhAAICsfNIAe/NIJ3AAMgDBAong");
	this.shape_19.setTransform(-619.4,-181.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAIsIm9AAIAAHsIIrAAIAAIqg");
	this.shape_20.setTransform(-835.65,-181.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABrUUIjPvfIgqAAIAAPfIpVAAMAAAgonIJ/AAQGcAACjC4QChC5AAFhIAAC6QAAF8jACmIEoR5gAiOirIAdAAQBNABAfglQAggiAAhWIAAj6QAAhWggglQgfgihNAAIgdAAg");
	this.shape_21.setTransform(-986.275,-181.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AACU6QlWAAivi4Qivi6AAlbIAAzVQAAlmC0i2QC0i1FKAAIAFAAQFUAACuC5QCsC7AAFdIAATVQAAFniyC0QixCylHAAgAhQqZIAAU2QAABtBQAAIACAAQBQAAAAhtIAA02QAAhvhSAAIgDAAQhNAAAABvg");
	this.shape_22.setTransform(-1148.575,-181.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AGpUUIAA+cIgbEpIivZzInAAAIix5zIgZkpIAAecIpCAAMAAAgonIOJAAIBWTQIANDEIAQjEIBczQIODAAMAAAAong");
	this.shape_23.setTransform(-1337.375,-181.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.daily_sub_caption_mc, new cjs.Rectangle(-1453.9,-381.7,3972.8,474.79999999999995), null);


(lib.bt_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-5952.9,-132.9,8.0463,8.0463);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bt_logo, new cjs.Rectangle(-5952.9,-132.9,1609.2999999999993,756.4), null);


(lib.big_win_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDcQhhhLAAiSQAAiEBhhRQBfhSCQAAQCRAABfBSQBhBRAACEQAACShhBLQhfBNiRAAQiQAAhfhNg");
	this.shape.setTransform(1451.225,-92.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIolAAIAAG7IG9AAIAAItIm9AAIAAHrIIrAAIAAIqg");
	this.shape_1.setTransform(1347.2,-195.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgHUUIil5vIAAZvIpVAAMAAAgonIMRAAICfZIIAA5IIJSAAMAAAAong");
	this.shape_2.setTransform(1193.4,-195.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("An0R3Qi+itAAlUIAA+ZIJhAAIAAepQAABtBSAAQBQAAAAhtIAA+pIJiAAIAAeZQAAE+ivC4QiwC4lQAAQk8AAi8itg");
	this.shape_3.setTransform(1025.2,-194.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ApwSDIDXoBQCWBRBxAAQBZAAAmg1QAjg1AAh6IAA8WIJhAAIAAd6QAAFTi2DBQi3DBk3AAQkNgBkwikg");
	this.shape_4.setTransform(867.925,-194);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AqFS+ICaoXQD+BjBsAAQDSAAAAijIAAgRQAAhJg0hQQgzhQiBiBIhxhtQi3i1hQidQhQiaAAj0IAAgHQAAlUCui/QCti+EzAAQD7gBEpB3IiZH2Qi+g7hZAAQjMAAgBCnIAAAJQAAAXAJAWQAHAWALAUQALATAXAdIAoAvIA3A5IA6A/QBQBWAqAnQC8C9BTCXQBSCYAAEHIAAAEQAAFgi6DIQi4DIkyAAQk0ABk0h9g");
	this.shape_5.setTransform(698.15,-196.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_6.setTransform(590.825,-195.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABRUUIAAwBIiiAAIAAQBIpUAAMAAAgonIJUAAIAAPWICiAAIAAvWIJVAAMAAAAong");
	this.shape_7.setTransform(474,-195.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AkoUUIAA/cIlvAAIAApLIUvAAIAAJLIltAAIAAfcg");
	this.shape_8.setTransform(331.825,-195.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AqyJqIAAzTQAAlNDYjEQDWjDFTAAQE+AAEmCkIjWIBQiXhRixAAQjoAAADEEIAAR0QAAB6BcAAQAqAAAZgPIAAurII0AAIAAUyQizBmiFAsQiFArixAAQrHAAAArUg");
	this.shape_9.setTransform(149.225,-196.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AkpUUMAAAgonIJTAAMAAAAong");
	this.shape_10.setTransform(31.075,-195.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Aq3UUMAAAgonIKPAAQFGAAC/CcQC/CfAAFEIAABAQAADKhAB6QhBB7iTBBQEwBsAAGtIAACeQAAFNi3CyQi5Cyk7AAgAhiLgIAkAAQBIAAAbgiQAcghAAhLIAAj/QAAhOgbgjQgZgkhLAAIgkAAgAhikiIAtAAQBJABAcgiQAagiAAhKIAAicQAAhMgZglQgagihMAAIgtAAg");
	this.shape_11.setTransform(-85.975,-195.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ao/UUMAAAgonIR5AAIAAIqIomAAIAAG7IG/AAIAAItIm/AAIAAHrIIsAAIAAIqg");
	this.shape_12.setTransform(-267.55,-195.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ABrUUIjPvfIgqAAIAAPfIpVAAMAAAgonIJ/AAQGcAACjC4QChC5AAFgIAAC7QAAF8jACnIEoR4gAiOirIAdAAQBNABAfglQAggiAAhWIAAj7QAAhVggglQgfgihNAAIgdAAg");
	this.shape_13.setTransform(-418.225,-195.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AACU6QlWAAivi4Qivi7AAlZIAAzWQAAlmC0i2QC0i1FKAAIAFAAQFUAACuC5QCsC7AAFdIAATWQAAFmiyC0QixCylHAAgAhQqYIAAU1QAABtBQAAIACAAQBQAAAAhtIAA01QAAhwhSAAIgDAAQhNAAAABwg");
	this.shape_14.setTransform(-580.475,-196.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABZU9QlwAAi+jHQi9jHAAmEIAAxVQAAmEC9jHQC+jHFwAAIAEAAQEZAADsBrIjWHgQhcgchxAAIgDAAQjsAAAAEdIAAPhQAACHBJBLQBJBLB7AAIADAAQBpAAB3gxIDTHfQkECBkyAAg");
	this.shape_15.setTransform(-721.9,-196.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AqFS+ICaoXQD+BjBsAAQDSAAAAijIAAgRQAAhJg0hQQgzhQiBiBIhxhtQi3i1hQidQhQiaAAj0IAAgHQAAlUCui/QCti+EzAAQD7gBEpB3IiZH2Qi+g7hZAAQjMAAgBCnIAAAJQAAAXAJAWQAHAWALAUQALATAXAdIAoAvIA3A5IA6A/QBQBWAqAnQC8C9BTCXQBSCYAAEHIAAAEQAAFgi6DIQi4DIkyAAQk0ABk0h9g");
	this.shape_16.setTransform(-865.15,-196.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_win_mc, new cjs.Rectangle(-939.3,-396.5,4162.7,474.8), null);


(lib.background_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._970x90();
	this.instance.setTransform(-485,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.background_mc, new cjs.Rectangle(-485,-45,970,90), null);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(560.05,-5.9,0.0151,0.0151,0,0,0,494.2,454.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAjIgBgPQAIACAGAAIAFgBQACgBABgGIgDAAQgIAAgEgDQgEgFACgIIAHgjIAQAAIgHAiQAAABAAABQAAAAABABQAAAAAAAAQABAAAAAAIABAAIAIglIARAAIgMA1QgCALgGAFQgFAFgKABQgGgBgHgCg");
	this.shape.setTransform(548.525,-3.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAlIAPhJIAQAAIgQBJg");
	this.shape_1.setTransform(545.3,-5.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAkIAPhJIAPAAIgDASIACAAQAKABADAEQADAFgCAKIgEARQgCAKgFAFQgFAFgJAAQgIAAgKgCgAgCAWIABAAIABgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAEgPIAAgEIgDgBIgBAAg");
	this.shape_2.setTransform(541.6444,-5.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgOAnIALg1IAQAAIgMA1gAABgXQgBgDAAgEQABgEACgCQADgCAEAAQADAAACACQABACgBAEQgBAEgCADQgCACgEAAQgEAAgBgCg");
	this.shape_3.setTransform(538.495,-5.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAbIAFgQQAHACAFAAQAFAAAAgCIAAgCIgCgBIgBgBIgCgBQgKgFADgMQABgHAFgFQAFgEAHAAQAIgBAHADIgFAPQgGgCgEAAQgFAAAAACIAAACIADABIADACQAFADACACQADAEgCAHQgBAIgGAFQgGAFgJAAQgHAAgIgCg");
	this.shape_4.setTransform(535.175,-4.8042);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgBAcIAHglQAAAAAAgBQAAgBgBAAQAAAAAAgBQgBAAAAAAIgCAAIgIAoIgQAAIALg0QALgDAIAAQASAAgDARIgJAmg");
	this.shape_5.setTransform(531.0285,-4.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAdQgSAAAEgVIADgPQAFgVARAAIAAAAQASAAgEAVIgEAPQgEAVgRAAgAAAgIIgDARQAAABAAABQAAABAAAAQAAABAAAAQAAAAABAAIAAAAQACAAAAgEIAEgRQAAgBAAgBQAAgBAAAAQAAgBAAAAQgBAAAAAAIgBAAQgCAAAAAEg");
	this.shape_6.setTransform(526.8086,-4.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgYAnIAQhLIASgCQAKABAEAEQACAFgCALIgDARQgCAJgFAFQgGAFgJAAIgCAAIgEAUgAAAADIAAAAIADgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAAAABgBIADgPIAAgFIgCgBIgBAAg");
	this.shape_7.setTransform(522.1444,-3.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVAbIAFgQQAHACAFAAQAFAAAAgCIAAgCIgCgBIgBgBIgCgBQgKgFADgMQABgHAFgFQAFgEAHAAQAIgBAHADIgFAPQgGgCgEAAQgFAAAAACIAAACIADABIADACQAFADACACQADAEgCAHQgBAIgGAFQgGAFgJAAQgHAAgIgCg");
	this.shape_8.setTransform(518.325,-4.8042);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQAXQgFgFADgLIADgOQACgLAFgFQAGgFAJAAQAJAAACAFQADAFgCALIgCAMIgTAAIgBADQgBAFAHAAIAIgBIgCAPIgLACQgKAAgEgGgAAAgJIAAAEIAEAAIABgEIAAgEIgBgBQgDAAgBAFg");
	this.shape_9.setTransform(514.4704,-4.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgBAlIAAgcIgBAAIgGAcIgRAAIAQhJIARAAQAMAAAEAEQADAGgCAKIgBAGQgCAKgHAFIACAggAAAgEIABAAIADgBQABAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAgBIACgHQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAAAIgCgBIgBAAg");
	this.shape_10.setTransform(509.8364,-5.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAjIgBgPQAIACAGAAIAFgBQACgBABgGIgDAAQgIAAgEgDQgEgFACgIIAHgjIAQAAIgHAiQAAABAAABQAAAAABABQAAAAAAAAQABAAAAAAIABAAIAIglIARAAIgMA1QgCALgGAFQgFAFgKABQgGgBgHgCg");
	this.shape_11.setTransform(504.075,-3.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgSAYQgEgEACgIIAAgBQACgIAFgDQAFgFAJAAIACAAIABgCQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAIgFgBQgEAAgIACIAIgQIAGgBIAFgBQALAAAEAFQACAFgBAJIgIAjQgMADgHAAQgJAAgDgFgAgCAGIgBADIgBACQAAAAAAABQAAAAAAAAQAAABABAAQAAABAAAAIACABIABAAIABgKIgBAAIgCABg");
	this.shape_12.setTransform(499.7,-4.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgPAlIAPhJIAQAAIgPBJg");
	this.shape_13.setTransform(496.55,-5.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgZAlIAQhJIARAAQAMAAADAEQAEAGgCAKIgBAHQgDAKgGAFQgGAEgKAAIgBAAIgGAbgAAAgDIAAAAIAEgBIACgEIACgIQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAIAAAAg");
	this.shape_14.setTransform(492.9833,-5.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgQAhIAAhBIAPAAQAIAAAFAFQAGAFAAAKIAAAZQAAAJgGAFQgFAGgIAAgAgCASIABAAQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAgBIABgDIAAgbIgBgEIgCgBIgBAAg");
	this.shape_15.setTransform(467.65,-5.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNAhIAAhBIAcAAIAAAOIgPAAIAAALIAMAAIAAAOIgMAAIAAAMIAPAAIAAAOg");
	this.shape_16.setTransform(464.1,-5.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAFAhIgBgNIgHAAIgBANIgPAAIAJhBIAVAAIAJBBgAAAgKIgBAQIADAAIgCgQIAAgGg");
	this.shape_17.setTransform(460.275,-5.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAAAhIgEgpIAAApIgOAAIAAhBIASAAIAEAoIAAgoIAPAAIAABBg");
	this.shape_18.setTransform(454.9,-5.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_19.setTransform(451.7,-5.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgPAfIADgOQAHACADAAQAEAAAAgDIAAgBIgBgEIgEgFIgDgDQgEgDgCgEQgCgFAAgGIAAAAQAAgJAEgEQAEgFAHAAQAGAAAIADIgEAMIgHgBQgEAAAAAEIAAACIAAABIAAABIABABIACABIABACIADAEQAFADACAEQACAEAAAHQAAAIgEAFQgFAGgHAAQgIAAgHgDg");
	this.shape_20.setTransform(447.925,-5.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgOAhIAAhBIAdAAIAAAOIgPAAIAAALIAMAAIAAAOIgMAAIAAAMIAPAAIAAAOg");
	this.shape_21.setTransform(444.65,-5.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgQAhIAAgOIARglIgPAAIAAgOIAfAAIAAANIgRAmIARAAIAAAOg");
	this.shape_22.setTransform(441.075,-5.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgGAhIAAhBIANAAIAABBg");
	this.shape_23.setTransform(438.2,-5.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AADAhIgFgZIgBAAIAAAZIgPAAIAAhBIAQAAQAKAAAEAEQAEAFAAAKIAAAEQAAAJgFAEIAIAdgAgDgDIABAAIACgBIABgEIAAgFIgBgEIgCgBIgBAAg");
	this.shape_24.setTransform(435.075,-5.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgQAhIAAhBIAQAAQAJAAAEAEQAEAFAAAKIAAAFQAAAJgEAEQgFADgIAAIgBAAIAAAZgAgBgCIAAAAIACgBIABgEIAAgGIgBgEIgCgBIAAAAg");
	this.shape_25.setTransform(430.975,-5.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgGAqIAAhTIANAAIAABTg");
	this.shape_26.setTransform(424.575,-4.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgHAhIAAgSIgMgvIAQAAIADAWIAFgWIAPAAIgMAvIAAASg");
	this.shape_27.setTransform(418.1,-5.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgPAhIAAhBIAPAAIAAAyIAQAAIAAAPg");
	this.shape_28.setTransform(414.15,-5.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgQAhIAAhBIAQAAQAJAAAEAEQAEAFAAAKIAAAFQAAAJgEAEQgFADgIAAIgBAAIAAAZgAgBgCIAAAAIACgBIABgEIAAgGIgBgEIgCgBIAAAAg");
	this.shape_29.setTransform(410.325,-5.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgQAhIAAhBIAQAAQAJAAAEAEQAEAFAAAKIAAAFQAAAJgEAEQgFADgIAAIgBAAIAAAZgAgBgCIAAAAIACgBIABgEIAAgGIgBgEIgCgBIAAAAg");
	this.shape_30.setTransform(406.375,-5.25);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAFAhIgBgNIgHAAIgBANIgPAAIAJhBIAVAAIAJBBgAAAgKIgBAQIADAAIgCgQIAAgGg");
	this.shape_31.setTransform(402.275,-5.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgPAfIADgOQAHACADAAQAEAAAAgDIAAgBIgBgEIgEgFIgDgDQgEgDgCgEQgCgFAAgGIAAAAQAAgJAEgEQAEgFAHAAQAGAAAIADIgEAMIgHgBQgEAAAAAEIAAACIAAABIAAABIABABIACABIABACIADAEQAFADACAEQACAEAAAHQAAAIgEAFQgFAGgHAAQgIAAgHgDg");
	this.shape_32.setTransform(397.375,-5.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgEAOIgCgbIANAAIgDAbg");
	this.shape_33.setTransform(394.6,-7.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgLAdQgFgFAAgKIAAgbQAAgKAFgFQAFgFAIAAQAHAAAGADIgFAMIgFgBQgFAAAAAIIAAAYQAAADABACQAAAAABABQAAAAABAAQAAAAABAAQAAAAABAAIABAAIAFgBIAGANQgHADgIAAQgIAAgFgFg");
	this.shape_34.setTransform(391.975,-5.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgRAdQgFgDAAgKIAAgIQAAgEACgDQACgCAEAAQgDgHAAgDIAAgGQAAgIADgEQADgEAJAAQAGAAACAEQADAEAAAIIAAAFQAAAJgJADIAGAHIgBgHIAMAAIAAAEIAAADIAAADIAAADIAAADIgBACIgBACIAIANIgPAAIgCgCQgEADgEAAQgLAAgEgFgAgIAKIAAAFQAAADACABQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIACAAIgIgNgAgEgTIAAACIAAAHIAAACQADAAAAgDIAAgGIAAgCIgCAAIgBAAIAAAAg");
	this.shape_35.setTransform(387.475,-5.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgHAhIAAgyIgJAAIAAgPIAhAAIAAAPIgJAAIAAAyg");
	this.shape_36.setTransform(383.175,-5.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgGAqIAAhTIANAAIAABTg");
	this.shape_37.setTransform(377.075,-4.35);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgMAdQgEgFAAgJIAAgEQAAgHAEgEQgDgEAAgGIAAgFQAAgIAEgFQAFgFAGAAQAHAAAEAFQAFAFAAAIIAAAFQAAAGgDAEQAEAEAAAHIAAAEQAAAJgFAFQgEAFgIAAQgHAAgFgFgAgBAIIAAAJQAAABAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAgBIAAgJQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAgAgBgRIAAALIABADIAAAAIABgBIABgCIAAgLQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAg");
	this.shape_38.setTransform(371.775,-5.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgMAdQgEgFAAgJIAAgEQAAgHAEgEQgDgEAAgGIAAgFQAAgIAEgFQAFgFAGAAQAHAAAEAFQAFAFAAAIIAAAFQAAAGgDAEQAEAEAAAHIAAAEQAAAJgFAFQgEAFgIAAQgHAAgFgFgAgBAIIAAAJQAAABAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABgBQAAAAAAgBIAAgJQAAAAAAgBQgBAAAAgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAgAgBgRIAAALIABADIAAAAIABgBIABgCIAAgLQAAAAAAgBQgBAAAAgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAg");
	this.shape_39.setTransform(367.875,-5.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgQAhIAAgNQATgUgBgLIAAgBQAAgDgCgBQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIgJACIgFgNQAHgDAJAAQAIAAAEAFQAFAGAAAIIAAABIgBAJQgCADgDAFIgEAHIgHAIIAQAAIAAANg");
	this.shape_40.setTransform(364,-5.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgPAfIADgOQAHACADAAQAEAAAAgDIAAgBIgBgEIgEgFIgDgDQgEgDgCgEQgCgFAAgGIAAAAQAAgJAEgEQAEgFAHAAQAGAAAIADIgEAMIgHgBQgEAAAAAEIAAACIAAABIAAABIABABIACABIABACIADAEQAFADACAEQACAEAAAHQAAAIgEAFQgFAGgHAAQgIAAgHgDg");
	this.shape_41.setTransform(359.375,-5.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgNAhIAAhBIAcAAIAAAOIgPAAIAAALIAMAAIAAAOIgMAAIAAAMIAPAAIAAAOg");
	this.shape_42.setTransform(356.1,-5.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgHAhIAAhBIAOAAIAABBg");
	this.shape_43.setTransform(353.4,-5.25);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AADAhIgFgZIgBAAIAAAZIgPAAIAAhBIAQAAQAKAAAEAEQAEAFAAAKIAAAEQAAAJgFAEIAIAdgAgDgDIABAAIACgBIABgEIAAgFIgBgEIgCgBIgBAAg");
	this.shape_44.setTransform(350.325,-5.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgNAhIAAhBIAcAAIAAAOIgPAAIAAALIAMAAIAAAOIgMAAIAAAMIAPAAIAAAOg");
	this.shape_45.setTransform(346.65,-5.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgPAfIADgOQAHACADAAQAEAAAAgDIAAgBIgBgEIgEgFIgDgDQgEgDgCgEQgCgFAAgGIAAAAQAAgJAEgEQAEgFAHAAQAGAAAIADIgEAMIgHgBQgEAAAAAEIAAACIAAABIAAABIABABIACABIABACIADAEQAFADACAEQACAEAAAHQAAAIgEAFQgFAGgHAAQgIAAgHgDg");
	this.shape_46.setTransform(343.225,-5.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(341.3,-12.7,226.09999999999997,14.899999999999999);


// stage content:
(lib.big_ticket_awareness_html5_970x90 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// footer
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(452.4,85.9,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(278));

	// logo
	this.instance_1 = new lib.bt_logo();
	this.instance_1.setTransform(484.95,25.9,0.0767,0.0767,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(278));

	// new_cta
	this.instance_2 = new lib.cta();
	this.instance_2.setTransform(787,24,0.6657,0.6657);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(278));

	// other_prizes
	this.instance_3 = new lib.other_prizes_mc();
	this.instance_3.setTransform(356.6,44.7,0.7094,0.7094,0,0,0,214.6,31.7);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(180).to({_off:false},0).wait(1).to({regX:240,regY:32.5,x:374.2,y:45.25,alpha:0.0037},0).wait(1).to({x:372.8,alpha:0.0167},0).wait(1).to({x:370,alpha:0.0435},0).wait(1).to({x:364.95,alpha:0.0919},0).wait(1).to({x:355.5,alpha:0.1816},0).wait(1).to({x:340.45,alpha:0.3248},0).wait(1).to({x:323.35,alpha:0.4878},0).wait(1).to({x:307.95,alpha:0.6345},0).wait(1).to({x:295.85,alpha:0.7499},0).wait(1).to({x:286.5,alpha:0.8388},0).wait(1).to({x:279.15,alpha:0.9088},0).wait(1).to({x:274.15,alpha:0.9564},0).wait(1).to({x:271.3,alpha:0.9834},0).wait(1).to({x:269.95,alpha:0.9964},0).wait(1).to({regX:214.6,regY:31.7,x:251.6,y:44.7,alpha:1},0).wait(68).to({regX:240,regY:32.5,scaleX:0.7093,scaleY:0.7093,x:269.75,y:45.25},0).wait(1).to({scaleX:0.709,scaleY:0.709,x:270.2},0).wait(1).to({scaleX:0.7084,scaleY:0.7084,x:271.25,y:45.2},0).wait(1).to({scaleX:0.7074,scaleY:0.7074,x:273.25,y:45.25},0).wait(1).to({scaleX:0.7055,scaleY:0.7055,x:276.75},0).wait(1).to({scaleX:0.7025,scaleY:0.7025,x:282.45},0).wait(1).to({scaleX:0.699,scaleY:0.699,x:288.85,y:45.2},0).wait(1).to({scaleX:0.6959,scaleY:0.6959,x:294.65,y:45.25},0).wait(1).to({scaleX:0.6934,scaleY:0.6934,x:299.2},0).wait(1).to({scaleX:0.6916,scaleY:0.6916,x:302.75},0).wait(1).to({scaleX:0.6901,scaleY:0.6901,x:305.5},0).wait(1).to({scaleX:0.6891,scaleY:0.6891,x:307.4},0).wait(1).to({scaleX:0.6885,scaleY:0.6885,x:308.5},0).wait(1).to({scaleX:0.6882,scaleY:0.6882,x:308.95},0).wait(1).to({regX:215,regY:32.1,scaleX:0.6881,scaleY:0.6881,x:291.65,y:44.7},0).wait(1));

	// Layer_1
	this.instance_4 = new lib.third_sub_caption_mc();
	this.instance_4.setTransform(531.05,69.6,0.0937,0.0937,0,0,0,490.3,-134.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(180).to({_off:false},0).wait(1).to({regX:407.7,regY:-203,x:523.3,y:63.1,alpha:0.0037},0).wait(1).to({y:62.85,alpha:0.0167},0).wait(1).to({y:62.3,alpha:0.0435},0).wait(1).to({y:61.35,alpha:0.0919},0).wait(1).to({y:59.55,alpha:0.1816},0).wait(1).to({y:56.7,alpha:0.3248},0).wait(1).to({y:53.4,alpha:0.4878},0).wait(1).to({y:50.5,alpha:0.6345},0).wait(1).to({y:48.2,alpha:0.7499},0).wait(1).to({y:46.4,alpha:0.8388},0).wait(1).to({y:45,alpha:0.9088},0).wait(1).to({y:44.05,alpha:0.9564},0).wait(1).to({y:43.5,alpha:0.9834},0).wait(1).to({y:43.25,alpha:0.9964},0).wait(1).to({regX:490.3,regY:-134.5,x:531.05,y:49.6,alpha:1},0).wait(68).to({regX:407.7,regY:-203,x:523.3,y:43.25,alpha:0.9963},0).wait(1).to({y:43.5,alpha:0.9833},0).wait(1).to({y:44.05,alpha:0.9565},0).wait(1).to({y:45,alpha:0.9081},0).wait(1).to({y:46.8,alpha:0.8184},0).wait(1).to({y:49.65,alpha:0.6752},0).wait(1).to({y:52.95,alpha:0.5122},0).wait(1).to({y:55.85,alpha:0.3655},0).wait(1).to({y:58.15,alpha:0.2501},0).wait(1).to({y:59.95,alpha:0.1612},0).wait(1).to({y:61.35,alpha:0.0912},0).wait(1).to({y:62.3,alpha:0.0436},0).wait(1).to({y:62.85,alpha:0.0166},0).wait(1).to({y:63.1,alpha:0.0036},0).wait(1).to({regX:490.3,regY:-134.5,x:531.05,y:69.6,alpha:0},0).wait(1));

	// second_prize_mc
	this.instance_5 = new lib.second_prize_mc();
	this.instance_5.setTransform(210.65,45.15,0.2765,0.2765,0,0,0,92.2,12);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(98).to({_off:false},0).wait(1).to({regX:92.1,regY:11.7,x:210.8,y:45.1,alpha:0.0037},0).wait(1).to({x:211.55,alpha:0.0167},0).wait(1).to({x:213.1,alpha:0.0435},0).wait(1).to({x:215.9,alpha:0.0919},0).wait(1).to({x:221.1,alpha:0.1816},0).wait(1).to({x:229.4,y:45.15,alpha:0.3248},0).wait(1).to({x:238.85,alpha:0.4878},0).wait(1).to({x:247.35,y:45.2,alpha:0.6345},0).wait(1).to({x:254.05,alpha:0.7499},0).wait(1).to({x:259.25,y:45.25,alpha:0.8388},0).wait(1).to({x:263.3,alpha:0.9088},0).wait(1).to({x:266.05,alpha:0.9564},0).wait(1).to({x:267.6,alpha:0.9834},0).wait(1).to({x:268.35,alpha:0.9964},0).wait(1).to({regX:92.2,regY:12,x:268.65,y:45.35,alpha:1},0).wait(68).to({regX:92.1,regY:11.7,x:268.6,y:45.3,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({alpha:0.9565},0).wait(1).to({alpha:0.9081},0).wait(1).to({alpha:0.8184},0).wait(1).to({alpha:0.6752},0).wait(1).to({alpha:0.5122},0).wait(1).to({alpha:0.3655},0).wait(1).to({alpha:0.2501},0).wait(1).to({alpha:0.1612},0).wait(1).to({alpha:0.0912},0).wait(1).to({alpha:0.0436},0).wait(1).to({alpha:0.0166},0).wait(1).to({alpha:0.0036},0).wait(1).to({regX:92.2,regY:12,x:268.65,y:45.35,alpha:0},0).wait(67).to({regX:0,regY:0,scaleX:0.3813,scaleY:0.3813,x:240.05,y:47.75},0).wait(1).to({regX:92.1,regY:11.7,scaleX:0.3809,scaleY:0.3809,x:275.85,y:52.15,alpha:0.0037},0).wait(1).to({scaleX:0.3796,scaleY:0.3796,x:278.25,y:52.1,alpha:0.0167},0).wait(1).to({scaleX:0.3769,scaleY:0.3769,x:283.2,y:51.9,alpha:0.0435},0).wait(1).to({scaleX:0.372,scaleY:0.372,x:292.2,y:51.6,alpha:0.0919},0).wait(1).to({scaleX:0.3629,scaleY:0.3629,x:308.85,y:51,alpha:0.1816},0).wait(1).to({scaleX:0.3483,scaleY:0.3483,x:335.55,y:50.05,alpha:0.3248},0).wait(1).to({scaleX:0.3318,scaleY:0.3318,x:365.8,y:49,alpha:0.4878},0).wait(1).to({scaleX:0.3169,scaleY:0.3169,x:393.05,y:48,alpha:0.6345},0).wait(1).to({scaleX:0.3052,scaleY:0.3052,x:414.5,y:47.25,alpha:0.7499},0).wait(1).to({scaleX:0.2962,scaleY:0.2962,x:431.05,y:46.65,alpha:0.8388},0).wait(1).to({scaleX:0.2891,scaleY:0.2891,x:444,y:46.2,alpha:0.9088},0).wait(1).to({scaleX:0.2842,scaleY:0.2842,x:452.9,y:45.9,alpha:0.9564},0).wait(1).to({scaleX:0.2815,scaleY:0.2815,x:457.95,y:45.7,alpha:0.9834},0).wait(1).to({scaleX:0.2802,scaleY:0.2802,x:460.3,y:45.65,alpha:0.9964},0).wait(1).to({regX:0,regY:0.6,scaleX:0.2798,scaleY:0.2798,x:435.25,y:42.35,alpha:1},0).wait(1));

	// su_sub_caption
	this.instance_6 = new lib.daily_sub_caption_mc();
	this.instance_6.setTransform(484.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(98).to({_off:false},0).wait(1).to({regX:486.7,regY:-181.9,x:530.25,y:45.25,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({alpha:0.0435},0).wait(1).to({alpha:0.0919},0).wait(1).to({alpha:0.1816},0).wait(1).to({y:45.2,alpha:0.3248},0).wait(1).to({alpha:0.4878},0).wait(1).to({y:45.15,alpha:0.6345},0).wait(1).to({alpha:0.7499},0).wait(1).to({y:45.1,alpha:0.8388},0).wait(1).to({alpha:0.9088},0).wait(1).to({alpha:0.9564},0).wait(1).to({alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:62.2,alpha:1},0).wait(68).to({regX:486.7,regY:-181.9,x:530.25,y:45.15,alpha:0.9963},0).wait(1).to({y:45.4,alpha:0.9833},0).wait(1).to({y:45.95,alpha:0.9565},0).wait(1).to({y:46.9,alpha:0.9081},0).wait(1).to({y:48.7,alpha:0.8184},0).wait(1).to({y:51.55,alpha:0.6752},0).wait(1).to({y:54.85,alpha:0.5122},0).wait(1).to({y:57.75,alpha:0.3655},0).wait(1).to({y:60.05,alpha:0.2501},0).wait(1).to({y:61.85,alpha:0.1612},0).wait(1).to({y:63.25,alpha:0.0912},0).wait(1).to({y:64.2,alpha:0.0436},0).wait(1).to({y:64.75,alpha:0.0166},0).wait(1).to({y:65,alpha:0.0036},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:82.2,alpha:0},0).to({_off:true},1).wait(82));

	// main_sub_caption_copy
	this.instance_7 = new lib.big_win_mc();
	this.instance_7.setTransform(484.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.instance_8 = new lib.sub_caption_mc();
	this.instance_8.setTransform(484.75,62.4,0.0937,0.0937,0,0,0,1.1,0.6);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},15).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},68).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[]},151).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(15).to({_off:false},0).wait(1).to({regX:277.6,regY:-196.3,x:510.65,y:43.95,alpha:0.0037},0).wait(1).to({alpha:0.0167},0).wait(1).to({alpha:0.0435},0).wait(1).to({y:44.05,alpha:0.0919},0).wait(1).to({y:44.1,alpha:0.1816},0).wait(1).to({y:44.3,alpha:0.3248},0).wait(1).to({y:44.45,alpha:0.4878},0).wait(1).to({y:44.6,alpha:0.6345},0).wait(1).to({y:44.75,alpha:0.7499},0).wait(1).to({y:44.85,alpha:0.8388},0).wait(1).to({y:44.9,alpha:0.9088},0).wait(1).to({y:45,alpha:0.9564},0).wait(1).to({alpha:0.9834},0).wait(1).to({alpha:0.9964},0).wait(1).to({regX:1.1,regY:0.6,x:484.75,y:63.5,alpha:1},0).wait(69).to({regX:277.6,regY:-196.3,x:510.65,y:45,alpha:0.9963},0).wait(1).to({alpha:0.9833},0).wait(1).to({alpha:0.9565},0).wait(1).to({y:44.9,alpha:0.9081},0).wait(1).to({y:44.85,alpha:0.8184},0).wait(1).to({y:44.65,alpha:0.6752},0).wait(1).to({y:44.5,alpha:0.5122},0).wait(1).to({y:44.35,alpha:0.3655},0).wait(1).to({y:44.2,alpha:0.2501},0).wait(1).to({y:44.1,alpha:0.1612},0).wait(1).to({y:44.05,alpha:0.0912},0).wait(1).to({y:43.95,alpha:0.0436},0).wait(1).to({alpha:0.0166},0).wait(1).to({alpha:0.0036},0).to({_off:true},1).wait(165));

	// promo
	this.instance_9 = new lib.promo_mc();
	this.instance_9.setTransform(114.6,45.5,0.0655,0.0655,0,0,0,-3118.8,16.8);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({regX:-3118.4,regY:16.7,x:115.15,alpha:0.0037},0).wait(1).to({x:117.1,alpha:0.0167},0).wait(1).to({x:121.1,alpha:0.0435},0).wait(1).to({x:128.35,alpha:0.0919},0).wait(1).to({x:141.8,alpha:0.1816},0).wait(1).to({x:163.3,alpha:0.3248},0).wait(1).to({x:187.75,alpha:0.4878},0).wait(1).to({x:209.75,alpha:0.6345},0).wait(1).to({x:227.05,alpha:0.7499},0).wait(1).to({x:240.4,alpha:0.8388},0).wait(1).to({x:250.9,alpha:0.9088},0).wait(1).to({x:258.05,alpha:0.9564},0).wait(1).to({x:262.1,alpha:0.9834},0).wait(1).to({x:264.05,alpha:0.9964},0).wait(1).to({regX:-3118.8,regY:16.8,x:264.6,alpha:1},0).wait(84).to({regX:-3118.4,regY:16.7,x:264.85,alpha:0.9963},0).wait(1).to({x:265.75,alpha:0.9833},0).wait(1).to({x:267.6,alpha:0.9565},0).wait(1).to({x:271,alpha:0.9081},0).wait(1).to({x:277.3,alpha:0.8184},0).wait(1).to({x:287.3,alpha:0.6752},0).wait(1).to({x:298.7,alpha:0.5122},0).wait(1).to({x:309,alpha:0.3655},0).wait(1).to({x:317.05,alpha:0.2501},0).wait(1).to({x:323.3,alpha:0.1612},0).wait(1).to({x:328.2,alpha:0.0912},0).wait(1).to({x:331.5,alpha:0.0436},0).wait(1).to({x:333.4,alpha:0.0166},0).wait(1).to({x:334.3,alpha:0.0036},0).wait(1).to({regX:-3118.8,regY:16.8,x:334.6,alpha:0},0).wait(149).to({regX:0,regY:0.7,scaleX:0.078,scaleY:0.078,x:484.95,y:43.5},0).wait(1).to({regX:-3118.4,regY:16.7,x:242.95,y:44.75,alpha:0.0037},0).wait(1).to({scaleX:0.0778,scaleY:0.0778,x:247.85,alpha:0.0167},0).wait(1).to({scaleX:0.0775,scaleY:0.0775,x:257.85,y:44.8,alpha:0.0435},0).wait(1).to({scaleX:0.0768,scaleY:0.0768,x:275.95,y:44.85,alpha:0.0919},0).wait(1).to({scaleX:0.0757,scaleY:0.0757,x:309.6,y:44.9,alpha:0.1816},0).wait(1).to({scaleX:0.0738,scaleY:0.0738,x:363.35,y:45.1,alpha:0.3248},0).wait(1).to({scaleX:0.0717,scaleY:0.0717,x:424.4,y:45.25,alpha:0.4878},0).wait(1).to({scaleX:0.0697,scaleY:0.0697,x:479.4,y:45.35,alpha:0.6345},0).wait(1).to({scaleX:0.0682,scaleY:0.0682,x:522.7,y:45.5,alpha:0.7499},0).wait(1).to({scaleX:0.0671,scaleY:0.0671,x:556,y:45.6,alpha:0.8388},0).wait(1).to({scaleX:0.0661,scaleY:0.0661,x:582.25,y:45.65,alpha:0.9088},0).wait(1).to({scaleX:0.0655,scaleY:0.0655,x:600.1,y:45.75,alpha:0.9564},0).wait(1).to({scaleX:0.0652,scaleY:0.0652,x:610.2,alpha:0.9834},0).wait(1).to({scaleX:0.065,scaleY:0.065,x:615.05,y:45.8,alpha:0.9964},0).wait(1).to({regX:0,regY:0.8,scaleX:0.0649,scaleY:0.0649,x:818.95,y:44.75,alpha:1},0).wait(1));

	// background
	this.instance_10 = new lib.background_mc();
	this.instance_10.setTransform(485.05,45.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(278));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(485.1,45.1,485,57.699999999999996);
// library properties:
lib.properties = {
	id: '8F9B67423E0CC34A8BA2D26890153A40',
	width: 970,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_2ndprize.png", id:"_2ndprize"},
		{src:"images/_970x90.jpg", id:"_970x90"},
		{src:"images/bigwin.png", id:"bigwin"},
		{src:"images/cta.png", id:"cta"},
		{src:"images/logo.png", id:"logo"},
		{src:"images/promo.png", id:"promo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F9B67423E0CC34A8BA2D26890153A40'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;